
import React from 'react';
// import { AuthProvider } from './contexts/AuthContext';
// import Router from './components/Router';
// import { ThemeProvider } from './contexts/ThemeContext';
// import { ToastProvider } from './contexts/ToastContext';
// import { SessionProvider } from './contexts/SessionContext';
// import { AuditProvider } from './contexts/AuditContext';
// import Toast from './components/Toast';

const App: React.FC = () => {
  return (
    // <ThemeProvider>
    //   <ToastProvider>
    //     <AuthProvider>
    //       <SessionProvider>
    //         <AuditProvider>
    //           <div className="min-h-screen bg-primary text-primary transition-colors duration-300">
    //             <Router />
    //             <Toast />
    //           </div>
    //         </AuditProvider>
    //       </SessionProvider>
    //     </AuthProvider>
    //   </ToastProvider>
    // </ThemeProvider>
    <h1>Teste</h1>
  );
};

export default App;
