
export type PunchType = 'in' | 'out' | 'break_start' | 'break_end';

export interface Punch {
  type: PunchType;
  timestamp: Date;
  taskId?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

export type UserStatus = 'out' | 'in' | 'on_break';

export type Page = 'dashboard' | 'settings' | 'profile' | 'monitor' | 'projects' | 'reports' | 'platform_admin';

export type Role = 'admin' | 'employee' | 'superadmin';

export interface WorkSchedule {
  start: string;
  end: string;
}

export interface Organization {
  id: string;
  name: string;
}

export interface User {
  id: string;
  organizationId: string;
  name: string;
  email: string;
  password?: string;
  role: Role;
  jobTitle: string;
  schedule: WorkSchedule[];
  monthlySalary?: number;
}

export interface JobTitle {
  id: string;
  organizationId: string;
  name: string;
}

export interface AppSettings {
  appName: string;
  appLogoUrl: string;
  appFaviconUrl: string;
  companyHours: WorkSchedule[];
}

// --- Nova Estrutura de Gerenciamento ---

export interface Client {
  id: string;
  organizationId: string;
  companyName: string;
  logoUrl: string;
  fullAddress: string;
  phone: string;
  email: string;
  whatsapp: string;
  responsiblePerson: string;
  observation: string;
}

export interface ServiceType {
  id: string;
  organizationId: string;
  name: string;
  hourlyRate: number;
}

export interface Workspace {
  id: string;
  organizationId: string;
  name: string;
  adminOnly: boolean;
}

export interface Board {
  id: string;
  organizationId: string;
  name: string;
  workspaceId: string;
}

export interface KanbanStage {
  id: string;
  organizationId: string;
  name: string;
  boardId: string;
  order: number;
}

export interface Task {
  id: string;
  organizationId: string;
  title: string;
  description: string;
  stageId: string;
  boardId: string;
  clientId: string | null;
  serviceTypeId: string | null;
  assignedUserId: string | null;
  // Campos avançados
  parentId?: string;
  timeSpentSeconds: number;
  activeTimerStartTime: number | null;
}

// --- Tipos para funcionalidades de produção ---

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  id: number;
  message: string;
  type: ToastType;
}

export interface AuditLog {
  id: string;
  organizationId: string;
  timestamp: Date;
  userId: string;
  userName: string;
  action: string;
  details: string;
}
