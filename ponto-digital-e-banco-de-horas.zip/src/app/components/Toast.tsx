
import React from 'react';
import { useToast } from '../contexts/ToastContext';
import { ToastType } from '../types';

const toastStyles: Record<ToastType, { bg: string; icon: string }> = {
  success: { bg: 'bg-green-500', icon: '✅' },
  error: { bg: 'bg-red-500', icon: '❌' },
  warning: { bg: 'bg-yellow-500', icon: '⚠️' },
  info: { bg: 'bg-blue-500', icon: 'ℹ️' },
};

const Toast: React.FC = () => {
  const { toasts } = useToast();

  return (
    <div className="fixed bottom-5 right-5 z-[100] space-y-3">
      {toasts.map(toast => (
        <div
          key={toast.id}
          className={`${toastStyles[toast.type].bg} text-white font-semibold py-3 px-5 rounded-lg shadow-xl flex items-center space-x-3 animate-fade-in-out`}
        >
          <span>{toastStyles[toast.type].icon}</span>
          <span>{toast.message}</span>
        </div>
      ))}
      <style>{`
        @keyframes fade-in-out {
          0% { opacity: 0; transform: translateY(20px); }
          10% { opacity: 1; transform: translateY(0); }
          90% { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(20px); }
        }
        .animate-fade-in-out {
          animation: fade-in-out 3s ease-in-out forwards;
        }
      `}</style>
    </div>
  );
};

export default Toast;
