
import React, { useState } from 'react';
import { useSession } from '../contexts/SessionContext';
import { useTheme } from '../contexts/ThemeContext';
import type { Page, AppSettings } from '../types';

interface HeaderProps {
  navigate: (page: Page) => void;
  appSettings: AppSettings;
}

const Header: React.FC<HeaderProps> = ({ navigate, appSettings }) => {
  const { user, logout } = useSession();
  const { theme, toggleTheme } = useTheme();
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!user) return null;

  const NavLink: React.FC<{page: Page, children: React.ReactNode, isMobile?: boolean}> = ({ page, children, isMobile }) => (
    <a href="#" onClick={(e) => { e.preventDefault(); navigate(page); if(isMobile) setMobileMenuOpen(false); }} className="text-secondary hover:text-primary transition-colors block py-2 px-3 rounded-md">
      {children}
    </a>
  );

  return (
    <header className="bg-secondary shadow-md sticky top-0 z-40">
      <nav className="container mx-auto px-4 sm:px-6 py-3">
        <div className="flex justify-between items-center">
            {/* Logo and Desktop Nav */}
            <div className="flex items-center space-x-6">
                <div 
                    className="flex items-center cursor-pointer"
                    onClick={() => user.role === 'superadmin' ? {} : navigate('dashboard')}
                >
                  {appSettings.appLogoUrl ? (
                    <img src={appSettings.appLogoUrl} alt="App Logo" className="h-8 w-auto mr-3" />
                  ) : (
                    <span className="text-2xl mr-2">🏢</span>
                  )}
                  <h1 className="text-xl font-bold text-primary">{appSettings.appName}</h1>
                </div>
                { user.role !== 'superadmin' &&
                  <div className="hidden md:flex items-center space-x-4">
                      <NavLink page="dashboard">Dashboard</NavLink>
                      <NavLink page="projects">Projetos</NavLink>
                  </div>
                }
            </div>

            {/* Right side: Theme toggle, User menu and Mobile menu button */}
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button onClick={toggleTheme} className="p-2 rounded-full text-secondary hover:bg-tertiary">
                {theme === 'dark' ? '☀️' : '🌙'}
              </button>
              
              <div className="hidden md:flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-primary font-semibold">{user.name}</p>
                    <p className="text-sm text-secondary capitalize">{user.jobTitle}</p>
                  </div>

                  <div className="relative group -my-2 py-2">
                    <button className="w-10 h-10 bg-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {user.name.charAt(0).toUpperCase()}
                    </button>
                    <div className="absolute right-0 top-full mt-2 w-48 bg-tertiary rounded-md shadow-lg py-1 z-20 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-200 border border-border-color">
                      { user.role !== 'superadmin' && <NavLink page="profile">Meu Perfil</NavLink> }
                      {user.role === 'admin' && (
                        <>
                          <NavLink page="monitor">Monitoramento</NavLink>
                          <NavLink page="reports">Relatórios</NavLink>
                          <NavLink page="settings">Cadastros</NavLink>
                        </>
                      )}
                      <a href="#" onClick={(e) => { e.preventDefault(); logout(); }} className="block px-3 py-2 text-sm text-secondary hover:bg-cyan-600 hover:text-white">Sair</a>
                    </div>
                  </div>
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden">
                  <button onClick={() => setMobileMenuOpen(!isMobileMenuOpen)} className="p-2 rounded-md text-secondary hover:bg-tertiary">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                  </button>
              </div>
            </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
            <div className="md:hidden mt-4">
                { user.role !== 'superadmin' && 
                  <>
                    <NavLink page="dashboard" isMobile>Dashboard</NavLink>
                    <NavLink page="projects" isMobile>Projetos</NavLink>
                    <hr className="my-2 border-border-color"/>
                    <NavLink page="profile" isMobile>Meu Perfil</NavLink>
                  </>
                }
                {user.role === 'admin' && (
                  <>
                    <NavLink page="monitor" isMobile>Monitoramento</NavLink>
                    <NavLink page="reports" isMobile>Relatórios</NavLink>
                    <NavLink page="settings" isMobile>Cadastros</NavLink>
                  </>
                )}
                <a href="#" onClick={(e) => { e.preventDefault(); logout(); }} className="block py-2 px-3 rounded-md text-secondary hover:text-primary">Sair</a>
            </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
