
import React, { useMemo, useState, useEffect } from 'react';
import type { Punch } from '../types';

interface HourBankSummaryProps {
  punches: Punch[];
  workDayDurationMs: number;
}

const formatDuration = (milliseconds: number): string => {
  if (milliseconds < 0) milliseconds = 0;
  const totalSeconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map(v => v.toString().padStart(2, '0')).join(':');
};

const formatBalance = (milliseconds: number): string => {
    const sign = milliseconds < 0 ? '-' : '+';
    const absMillis = Math.abs(milliseconds);
    return sign + formatDuration(absMillis);
};

const SummaryItem: React.FC<{ label: string; value: string; valueColor?: string }> = ({ label, value, valueColor = "text-white" }) => (
    <div className="bg-gray-700/50 p-4 rounded-lg flex items-center justify-between">
        <span className="text-gray-300">{label}</span>
        <span className={`font-mono text-2xl font-bold ${valueColor}`}>{value}</span>
    </div>
);


const HourBankSummary: React.FC<HourBankSummaryProps> = ({ punches, workDayDurationMs }) => {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(intervalId);
  }, []);

  const { workedMs, breakMs } = useMemo(() => {
    let totalWork = 0;
    let totalBreak = 0;

    const relevantPunches = punches.filter(p => ['in', 'out', 'break_start', 'break_end'].includes(p.type));
    
    let lastIn: Date | null = null;
    let lastBreakStart: Date | null = null;

    relevantPunches.forEach(punch => {
        const timestamp = new Date(punch.timestamp); // Certifique-se que é um objeto Date
        switch(punch.type) {
            case 'in':
                if (!lastIn) lastIn = timestamp;
                break;
            case 'out':
                if (lastIn) {
                    totalWork += (timestamp.getTime() - lastIn.getTime());
                    lastIn = null;
                }
                break;
            case 'break_start':
                if (lastIn && !lastBreakStart) { // Só pode iniciar pausa se estiver trabalhando
                    lastBreakStart = timestamp;
                }
                break;
            case 'break_end':
                if (lastBreakStart) {
                    totalBreak += (timestamp.getTime() - lastBreakStart.getTime());
                    lastBreakStart = null;
                }
                break;
        }
    });

    // Se ainda estiver trabalhando no final do dia
    if(lastIn && !punches.some(p => p.type === 'out' && new Date(p.timestamp) > lastIn!)) {
        totalWork += (now.getTime() - lastIn.getTime());
    }

    // Se ainda estiver em pausa
    if(lastBreakStart) {
        totalBreak += (now.getTime() - lastBreakStart.getTime());
    }
    
    return { workedMs: totalWork, breakMs: totalBreak };
  }, [punches, now]);

  const netWorkedMs = workedMs - breakMs;
  const balanceMs = netWorkedMs - workDayDurationMs;

  const balanceColor = balanceMs >= 0 ? 'text-green-400' : 'text-red-400';

  return (
    <div className="bg-gray-800 rounded-2xl shadow-lg p-6">
      <h3 className="text-xl font-bold mb-4 text-cyan-400 border-b-2 border-gray-700 pb-2">Resumo do Dia</h3>
      <div className="space-y-3">
        <SummaryItem label="Jornada (Bruto)" value={formatDuration(workedMs)} />
        <SummaryItem label="Total Pausas" value={formatDuration(breakMs)} />
        <SummaryItem label="Jornada (Líquido)" value={formatDuration(netWorkedMs)} valueColor="text-cyan-400" />
        <SummaryItem label="Saldo do Banco" value={formatBalance(balanceMs)} valueColor={balanceColor} />
      </div>
    </div>
  );
};

export default HourBankSummary;
