
import React, { useState, useEffect } from 'react';
import { Board, Task, User, KanbanStage, Client, ServiceType } from '../types';
import * as projectService from '../services/projectService';
import * as userService from '../services/userService';
import * as settingsService from '../services/settingsService';
import { useAuth } from '../hooks/useAuth';
import TaskDetailModal from './TaskDetailModal';
import { useToast } from '../contexts/ToastContext';
import { useAudit } from '../contexts/AuditContext';
import ConfirmDialog from './ConfirmDialog';

interface KanbanBoardProps {
  board: Board;
}

const KanbanBoard: React.FC<KanbanBoardProps> = ({ board }) => {
  const { user, activeTask, setActiveTask } = useAuth();
  const [stages, setStages] = useState<KanbanStage[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [serviceTypes, setServiceTypes] = useState<ServiceType[]>([]);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [draggedStageId, setDraggedStageId] = useState<string | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | Omit<Task, 'id' | 'organizationId'> | null>(null);
  const [stageToDelete, setStageToDelete] = useState<string | null>(null);
  const { addToast } = useToast();
  const { logAction } = useAudit();
  
  const orgId = user!.organizationId;

  const reloadData = () => {
    setStages(projectService.getStages(orgId).filter(s => s.boardId === board.id).sort((a,b) => a.order - b.order));
    setTasks(projectService.getTasks(orgId).filter(t => t.boardId === board.id));
    setUsers(userService.getUsers(orgId));
    setClients(settingsService.getClients(orgId));
    setServiceTypes(settingsService.getServiceTypes(orgId));
  };

  useEffect(() => {
    reloadData();
  }, [board.id, orgId]);
  
  const handleTaskDrop = (targetStageId: string) => {
    if (draggedTaskId === null) return;
    const task = tasks.find(t => t.id === draggedTaskId);
    if (task && task.stageId !== targetStageId) {
        const updatedTask = { ...task, stageId: targetStageId };
        projectService.updateTask(orgId, updatedTask);
        logAction('Move Task', `Tarefa "${task.title}" movida para nova etapa.`);
        setTasks(prev => prev.map(t => t.id === draggedTaskId ? updatedTask : t));
    }
    setDraggedTaskId(null);
  };
  
  const handleStageDrop = (targetStage: KanbanStage) => {
    if (draggedStageId === null || draggedStageId === targetStage.id) return;
    
    let reorderedStages = [...stages];
    const draggedIndex = reorderedStages.findIndex(s => s.id === draggedStageId);
    const targetIndex = reorderedStages.findIndex(s => s.id === targetStage.id);
    const [draggedItem] = reorderedStages.splice(draggedIndex, 1);
    reorderedStages.splice(targetIndex, 0, draggedItem);
    
    reorderedStages = reorderedStages.map((stage, index) => ({ ...stage, order: index }));
    
    const allStagesFromStorage = projectService.getStages(orgId);
    const updatedAllStages = allStagesFromStorage.map(s => reorderedStages.find(rs => rs.id === s.id) || s);
    projectService.saveStages(orgId, updatedAllStages);

    setStages(reorderedStages);
    setDraggedStageId(null);
  };

  const handleTaskUpdate = (updatedTask: Task) => {
    setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
    if (activeTask && activeTask.id === updatedTask.id) {
        setActiveTask(updatedTask);
    }
  };

  const handleTaskAdded = (newTask: Task) => setTasks(prev => [...prev, newTask]);
  
  const handleTaskDelete = (taskId: string) => {
    if (activeTask?.id === taskId) setActiveTask(null);
    projectService.deleteTask(orgId, taskId);
    reloadData();
    setSelectedTask(null);
  };
  
  const handleAddStage = (name: string) => {
    if (name) {
      projectService.addStage(orgId, { name, boardId: board.id, order: stages.length });
      logAction('Create Stage', `Etapa "${name}" criada no quadro "${board.name}".`);
      addToast('Etapa criada com sucesso!', 'success');
      reloadData();
    }
  };
  const handleUpdateStage = (id: string, name: string) => {
    if (name) {
      const stage = stages.find(s => s.id === id);
      if (stage) {
        projectService.updateStage(orgId, { ...stage, name });
        logAction('Update Stage', `Etapa "${stage.name}" renomeada para "${name}".`);
        addToast('Etapa atualizada!', 'success');
        reloadData();
      }
    }
  };
  const handleDeleteStage = () => {
    if (stageToDelete !== null) {
        const stageName = stages.find(s => s.id === stageToDelete)?.name || '';
        projectService.deleteStage(orgId, stageToDelete);
        logAction('Delete Stage', `Etapa "${stageName}" excluída do quadro "${board.name}".`);
        addToast('Etapa excluída com sucesso.', 'success');
        reloadData();
    }
    setStageToDelete(null);
  };

  const handleOpenNewTaskModal = (stageId: string) => {
    setSelectedTask({
        title: '', description: '', stageId, boardId: board.id,
        clientId: null, serviceTypeId: null, assignedUserId: null,
        timeSpentSeconds: 0, activeTimerStartTime: null
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl h-full flex flex-col border border-gray-200 dark:border-gray-600">
      <h2 className="text-2xl font-bold text-cyan-400 mb-6 flex-shrink-0">{board.name}</h2>
      <div className="flex gap-6 overflow-x-auto flex-grow pb-4">
        {stages.map(stage => (
          <KanbanColumn 
            key={stage.id} 
            stage={stage} 
            onTaskDrop={handleTaskDrop} 
            onStageDrop={handleStageDrop}
            onDragStart={id => setDraggedStageId(id)}
            onAddNewTask={() => handleOpenNewTaskModal(stage.id)}
            onUpdateStage={handleUpdateStage}
            onDeleteStage={() => setStageToDelete(stage.id)}
          >
            {tasks.filter(t => t.stageId === stage.id && !t.parentId).map(task => (
                <TaskCard 
                    key={task.id} 
                    task={task} 
                    user={users.find(u => u.id === task.assignedUserId)}
                    isActive={activeTask?.id === task.id}
                    onDragStart={setDraggedTaskId} 
                    onClick={() => setSelectedTask(task)}
                />
            ))}
          </KanbanColumn>
        ))}
        <NewStageColumn onAddStage={handleAddStage} />
      </div>
      {selectedTask && (
        <TaskDetailModal
          key={('id' in selectedTask) ? selectedTask.id : 'new'}
          boardStages={stages}
          users={users}
          clients={clients}
          serviceTypes={serviceTypes}
          taskData={selectedTask}
          onClose={() => setSelectedTask(null)}
          onSave={handleTaskUpdate}
          onDelete={handleTaskDelete}
          onTaskAdded={handleTaskAdded}
        />
      )}
      <ConfirmDialog 
        isOpen={stageToDelete !== null}
        title="Excluir Etapa"
        message="Tem certeza? Excluir esta etapa removerá todas as tarefas dentro dela permanentemente."
        onConfirm={handleDeleteStage}
        onCancel={() => setStageToDelete(null)}
      />
    </div>
  );
};

const KanbanColumn: React.FC<{
    stage: KanbanStage; children: React.ReactNode;
    onTaskDrop: (stageId: string) => void; onStageDrop: (stage: KanbanStage) => void;
    onDragStart: (stageId: string) => void; onAddNewTask: () => void;
    onUpdateStage: (id: string, name: string) => void; onDeleteStage: (id: string) => void;
}> = ({ stage, children, onTaskDrop, onStageDrop, onDragStart, onAddNewTask, onUpdateStage, onDeleteStage }) => {
    const [isTaskOver, setIsTaskOver] = useState(false);
    const [isEditingName, setIsEditingName] = useState(false);
    const [stageName, setStageName] = useState(stage.name);

    const handleNameSave = () => { onUpdateStage(stage.id, stageName); setIsEditingName(false); };

    return (
        <div 
            draggable
            onDragStart={(e) => { e.stopPropagation(); onDragStart(stage.id); }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => { e.stopPropagation(); onStageDrop(stage); }}
            className="w-72 bg-gray-100 dark:bg-gray-700 rounded-xl p-2 flex flex-col flex-shrink-0 cursor-grab"
        >
            <div className="flex justify-between items-center p-2">
                {isEditingName ? (
                    <input value={stageName} onChange={e => setStageName(e.target.value)} onBlur={handleNameSave} onKeyDown={e => e.key === 'Enter' && handleNameSave()} className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-50 font-bold w-full outline-none" autoFocus/>
                ) : (
                    <h3 onClick={() => setIsEditingName(true)} className="text-md font-bold text-gray-900 dark:text-gray-50 cursor-pointer">{stage.name}</h3>
                )}
                 <div className="relative group">
                    <button className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-50">...</button>
                    <div className="absolute right-0 top-full mt-1 w-36 bg-white dark:bg-gray-800 rounded shadow-lg py-1 z-10 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 border border-gray-200 dark:border-gray-600">
                        <a href="#" onClick={(e) => {e.preventDefault(); onAddNewTask()}} className="block px-3 py-1 text-sm text-gray-700 dark:text-gray-300 hover:bg-cyan-600 hover:text-white">Adicionar Tarefa</a>
                        <a href="#" onClick={(e) => {e.preventDefault(); onDeleteStage(stage.id)}} className="block px-3 py-1 text-sm text-red-400 hover:bg-red-500 hover:text-white">Excluir Etapa</a>
                    </div>
                </div>
            </div>
            <div 
                onDragOver={(e) => { e.preventDefault(); setIsTaskOver(true); }}
                onDragLeave={() => setIsTaskOver(false)}
                onDrop={(e) => { e.preventDefault(); e.stopPropagation(); setIsTaskOver(false); onTaskDrop(stage.id); }}
                className={`space-y-4 h-full overflow-y-auto p-2 rounded transition-colors ${isTaskOver ? 'bg-white/50 dark:bg-gray-800/50' : ''}`}
            >
                {children}
            </div>
        </div>
    );
};

const NewStageColumn: React.FC<{onAddStage: (name: string) => void}> = ({ onAddStage }) => {
    const [isAdding, setIsAdding] = useState(false);
    const [name, setName] = useState('');

    const handleSave = () => { if (name.trim()) { onAddStage(name); setName(''); setIsAdding(false); } };

    if (isAdding) {
        return (
            <div className="w-72 bg-gray-100/50 dark:bg-gray-700/50 rounded-xl p-4 flex-shrink-0">
                <input value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSave()} placeholder="Nome da Etapa" className="w-full bg-white dark:bg-gray-800 p-2 rounded" autoFocus />
                <div className="flex items-center space-x-2 mt-2">
                    <button onClick={handleSave} className="px-3 py-1 bg-cyan-600 rounded text-sm">Adicionar</button>
                    <button onClick={() => setIsAdding(false)} className="text-gray-700 dark:text-gray-300 text-2xl">&times;</button>
                </div>
            </div>
        );
    }

    return (
        <div className="w-72 flex-shrink-0">
            <button onClick={() => setIsAdding(true)} className="w-full p-2 rounded-xl bg-gray-900/10 hover:bg-gray-900/20 dark:bg-gray-50/10 dark:hover:bg-gray-50/20 text-gray-900 dark:text-gray-50 font-semibold">
                + Adicionar Etapa
            </button>
        </div>
    );
};

const TaskCard: React.FC<{ task: Task, user?: User, isActive: boolean, onDragStart: (taskId: string) => void; onClick: () => void; }> = ({ task, user, isActive, onDragStart, onClick }) => (
    <div
        draggable
        onDragStart={(e) => { e.stopPropagation(); onDragStart(task.id); }}
        onClick={onClick}
        className={`bg-white dark:bg-gray-800 p-3 rounded-lg shadow-md cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-600 hover:border-cyan-500 transition-all ${isActive ? 'ring-2 ring-cyan-500 shadow-cyan-500/30' : ''}`}
    >
        <p className="font-semibold text-gray-900 dark:text-gray-50 text-sm">{task.title}</p>
        <div className="flex justify-between items-center mt-3 pt-2 border-t border-gray-200/50 dark:border-gray-600/50">
            {user ? (
                 <div className="w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center text-white text-xs font-bold" title={user.name}>
                    {user.name.charAt(0).toUpperCase()}
                 </div>
            ) : <div className="w-6 h-6"></div>}
            {isActive && (
                <svg className="h-5 w-5 text-cyan-400 animate-pulse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.414-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
            )}
        </div>
    </div>
);

export default KanbanBoard;
