
import React from 'react';
import type { Punch } from '../types';

interface TimeLogProps {
  punches: Punch[];
}

const punchTypeMap: { [key in Punch['type']]: { text: string; color: string; icon: React.ReactNode } } = {
  in: { text: 'Entrada', color: 'text-green-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414l-3-3z" clipRule="evenodd" /></svg> },
  out: { text: 'Saída', color: 'text-red-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-.707-4.707a1 1 0 001.414 1.414l3-3a1 1 0 00-1.414-1.414L11 10.586V7a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3z" clipRule="evenodd" /></svg> },
  break_start: { text: 'Início Pausa', color: 'text-yellow-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9 9a1 1 0 000 2h2a1 1 0 100-2H9z" clipRule="evenodd" /></svg> },
  break_end: { text: 'Fim Pausa', color: 'text-blue-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a8 8 0 100 16 8 8 0 000-16zM9.555 12.168l-3.197-2.132A1 1 0 017 9.87v4.263a1 1 0 01-1.555.832l-3.197-2.132a1 1 0 010-1.664l3.197-2.132A1 1 0 017 8.13v4.263a1 1 0 011.555.832l3.197 2.132a1 1 0 010 1.664l-3.197 2.132A1 1 0 019.555 12.168z" /></svg> },
};

const TimeLog: React.FC<TimeLogProps> = ({ punches }) => {
  return (
    <div className="bg-gray-800 rounded-2xl shadow-lg p-6">
      <h3 className="text-xl font-bold mb-4 text-cyan-400 border-b-2 border-gray-700 pb-2">Registros de Hoje</h3>
      <div className="max-h-60 overflow-y-auto pr-2">
        {punches.length === 0 ? (
          <p className="text-gray-400 text-center py-8">Nenhum registro ainda.</p>
        ) : (
          <ul className="space-y-3">
            {[...punches].reverse().map((punch, index) => (
              <li key={index} className="flex items-center justify-between bg-gray-700/50 p-3 rounded-lg">
                <div className="flex items-center">
                    <span className={`mr-3 ${punchTypeMap[punch.type].color}`}>{punchTypeMap[punch.type].icon}</span>
                    <span className={`font-semibold ${punchTypeMap[punch.type].color}`}>
                        {punchTypeMap[punch.type].text}
                    </span>
                </div>
                <span className="font-mono text-gray-300">{punch.timestamp.toLocaleTimeString('pt-BR')}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default TimeLog;
