
import React, { useState, useEffect } from 'react';
import { useSession } from '../contexts/SessionContext';
import LoginPage from '../pages/LoginPage';
import DashboardPage from '../pages/DashboardPage';
import SettingsPage from '../pages/SettingsPage';
import ProfilePage from '../pages/ProfilePage';
import MonitorPage from '../pages/MonitorPage';
import ProjectsPage from '../pages/ProjectsPage';
import ReportsPage from '../pages/ReportsPage';
import PlatformAdminPage from '../pages/PlatformAdminPage';
import Header from './Header';
import { getSettings } from '../services/settingsService';
import { AppSettings, Page } from '../types';
import { useTheme } from '../contexts/ThemeContext';

const Router: React.FC = () => {
  const { isAuthenticated, user } = useSession();
  const { theme } = useTheme();
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [settings, setSettings] = useState<AppSettings>(getSettings());

  useEffect(() => {
    document.title = settings.appName;
    const favicon = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
    if (favicon && settings.appFaviconUrl) {
      favicon.href = settings.appFaviconUrl;
    }
  }, [settings]);
  
  useEffect(() => {
    const rootHtml = document.documentElement;
    rootHtml.classList.remove('light', 'dark');
    rootHtml.classList.add(theme);
  }, [theme]);


  const handleSettingsUpdate = (newSettings: AppSettings) => {
    setSettings(newSettings);
  };
  
  if (!isAuthenticated || !user) {
    return <LoginPage />;
  }
  
  if (user.role === 'superadmin') {
      return (
         <>
          <Header navigate={setCurrentPage} appSettings={settings} />
          <main className="p-2 sm:p-4 md:p-6 lg:p-8">
            <PlatformAdminPage />
          </main>
         </>
      );
  }


  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'projects':
        return <ProjectsPage />;
      case 'settings':
        return user.role === 'admin' ? <SettingsPage onSettingsUpdate={handleSettingsUpdate} /> : <DashboardPage />;
      case 'profile':
        return <ProfilePage navigate={setCurrentPage} />;
      case 'monitor':
        return user.role === 'admin' ? <MonitorPage /> : <DashboardPage />;
      case 'reports':
        return user.role === 'admin' ? <ReportsPage /> : <DashboardPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <>
      <Header navigate={setCurrentPage} appSettings={settings} />
      <main className="p-2 sm:p-4 md:p-6 lg:p-8">
        {renderPage()}
      </main>
      <footer className="w-full max-w-5xl mx-auto text-center mt-12 pb-8 text-secondary/50">
        <p>&copy; {new Date().getFullYear()} {settings.appName}. Todos os direitos reservados.</p>
      </footer>
    </>
  );
};

export default Router;