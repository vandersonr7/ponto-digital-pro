
import React, { useState, useEffect } from 'react';
import { Task, KanbanStage, User, Client, ServiceType, UserStatus } from '../types';
import * as timeService from '../services/timeService';
import * as projectService from '../services/projectService';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../contexts/ToastContext';
import { useAudit } from '../contexts/AuditContext';
import ConfirmDialog from './ConfirmDialog';

interface TaskDetailModalProps {
  taskData: Task | Omit<Task, 'id' | 'organizationId'>;
  boardStages: KanbanStage[];
  users: User[];
  clients: Client[];
  serviceTypes: ServiceType[];
  onClose: () => void;
  onSave: (task: Task) => void;
  onDelete: (taskId: string) => void;
  onTaskAdded: (task: Task) => void;
}

const formatTime = (totalSeconds: number) => {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return [hours, minutes, seconds].map(v => v.toString().padStart(2, '0')).join(':');
};

const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  taskData, boardStages, users, clients, serviceTypes, onClose, onSave, onDelete, onTaskAdded
}) => {
  const { user, activeTask, setActiveTask } = useAuth();
  const [formData, setFormData] = useState(taskData);
  const [subtasks, setSubtasks] = useState<Task[]>([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [userStatus, setUserStatus] = useState<UserStatus>('out');
  const [isConfirmOpen, setConfirmOpen] = useState(false);
  const { addToast } = useToast();
  const { logAction } = useAudit();
  
  const orgId = user!.organizationId;

  const isTimerActive = activeTask?.id === ('id' in formData ? formData.id : '-1');
  const [timeSpent, setTimeSpent] = useState(formData.timeSpentSeconds || 0);

   useEffect(() => {
    if (user) {
      const userPunches = timeService.getPunchesForUser(orgId, user.id);
      if (userPunches.length > 0) {
        const lastPunch = userPunches[userPunches.length - 1];
        if (lastPunch.type === 'in' || lastPunch.type === 'break_end') setUserStatus('in');
        else if (lastPunch.type === 'break_start') setUserStatus('on_break');
        else setUserStatus('out');
      } else {
        setUserStatus('out');
      }
    }
  }, [user, orgId]);

  useEffect(() => {
    if ('id' in formData) {
      setSubtasks(projectService.getTasks(orgId).filter(t => t.parentId === formData.id));
    }

    let interval: number | undefined;
    if (isTimerActive && activeTask?.activeTimerStartTime) {
        const startTime = activeTask.activeTimerStartTime;
        interval = window.setInterval(() => {
            const elapsed = (Date.now() - startTime) / 1000;
            setTimeSpent((activeTask.timeSpentSeconds || 0) + elapsed);
        }, 1000);
    } else {
      setTimeSpent(formData.timeSpentSeconds || 0);
    }
    return () => clearInterval(interval);
  }, [formData, isTimerActive, activeTask, orgId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };
  
  const handleNullableSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setFormData(prev => ({ ...prev, [e.target.name]: e.target.value || null }));
  };

  const handleSave = () => {
    if (!formData.title.trim()) {
        addToast("O título da tarefa é obrigatório.", 'error');
        return;
    }
    const action = 'id' in formData ? 'Update' : 'Create';
    if (!('id' in formData)) {
        const addedTask = projectService.addTask(orgId, formData);
        onTaskAdded(addedTask);
    } else {
        const updatedTask = projectService.updateTask(orgId, formData);
        onSave(updatedTask);
    }
    logAction(action, `Tarefa: "${formData.title}"`);
    addToast(`Tarefa ${'id' in formData ? 'atualizada' : 'criada'} com sucesso!`, 'success');
    onClose();
  };

  const handleStartTimer = () => {
    if ('id' in formData && userStatus === 'in') {
      const updatedTask = { ...formData, activeTimerStartTime: Date.now() };
      projectService.updateTask(orgId, updatedTask);
      setActiveTask(updatedTask);
      onSave(updatedTask);
      addToast('Timer iniciado!', 'info');
    } else {
      addToast("Você precisa bater o ponto de entrada no Dashboard para iniciar um timer.", 'warning');
    }
  };

  const handleStopTimer = () => {
    if ('id' in formData) {
      setActiveTask(null);
      const updatedTaskFromStorage = projectService.getTasks(orgId).find(t => t.id === formData.id);
      if (updatedTaskFromStorage) {
        setFormData(updatedTaskFromStorage);
        onSave(updatedTaskFromStorage);
      }
      addToast('Timer parado.', 'info');
    }
  };

  const handleAddSubtask = () => {
    if (newSubtaskTitle.trim() && 'id' in formData) {
        const subtaskData = {
            title: newSubtaskTitle, description: '', stageId: formData.stageId, boardId: formData.boardId,
            clientId: formData.clientId, serviceTypeId: formData.serviceTypeId, assignedUserId: formData.assignedUserId,
            parentId: formData.id, timeSpentSeconds: 0, activeTimerStartTime: null
        };
        const newSub = projectService.addTask(orgId, subtaskData);
        setSubtasks(prev => [...prev, newSub]);
        logAction('Create Subtask', `Subtarefa "${newSubtaskTitle}" criada para "${formData.title}".`);
        setNewSubtaskTitle('');
    }
  };
  
  const handleFinalize = () => {
    if (!('id' in formData)) return;
    const finalStage = boardStages.sort((a,b) => b.order - a.order)[0];
    if (finalStage) {
        const updatedTask = {...formData, stageId: finalStage.id};
        projectService.updateTask(orgId, updatedTask);
        onSave(updatedTask);
        logAction('Finalize Task', `Tarefa "${formData.title}" finalizada.`);
        addToast('Tarefa finalizada!', 'success');
        onClose();
    }
  };
  
  const handleDelete = () => {
    if ('id' in formData) {
        onDelete(formData.id);
    }
    setConfirmOpen(false);
  };

  return (
    <>
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 transition-opacity" onClick={onClose}>
      <div className="bg-secondary rounded-2xl shadow-xl p-6 w-full max-w-2xl m-4 border border-border-color flex flex-col max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
        <div className="flex-shrink-0">
          <input name="title" value={formData.title} onChange={handleChange} placeholder="Título da Tarefa" className="w-full bg-transparent text-2xl font-bold text-primary outline-none" />
          <textarea name="description" value={formData.description || ''} onChange={handleChange} placeholder="Adicione uma descrição..." rows={3} className="w-full bg-tertiary rounded-md p-2 mt-2 text-secondary outline-none focus:ring-1 focus:ring-cyan-500"></textarea>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-4 flex-shrink-0">
            <select name="assignedUserId" value={formData.assignedUserId || ''} onChange={handleNullableSelectChange} className="w-full bg-tertiary rounded px-3 py-2 text-primary text-sm border border-border-color"><option value="">Não atribuído</option>{users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
            <select name="stageId" value={formData.stageId} onChange={handleChange} className="w-full bg-tertiary rounded px-3 py-2 text-primary text-sm border border-border-color">{boardStages.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            <select name="clientId" value={formData.clientId || ''} onChange={handleNullableSelectChange} className="w-full bg-tertiary rounded px-3 py-2 text-primary text-sm border border-border-color"><option value="">Nenhum cliente</option>{clients.map(c => <option key={c.id} value={c.id}>{c.companyName}</option>)}</select>
            <select name="serviceTypeId" value={formData.serviceTypeId || ''} onChange={handleNullableSelectChange} className="w-full bg-tertiary rounded px-3 py-2 text-primary text-sm border border-border-color"><option value="">Nenhum serviço</option>{serviceTypes.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
        </div>

        <div className="bg-primary/5 p-3 rounded-lg flex items-center justify-between my-2 flex-shrink-0">
            <div className="text-primary">
                <span className="text-sm text-secondary">Tempo Gasto: </span>
                <span className="font-mono text-lg font-bold">{formatTime(timeSpent)}</span>
            </div>
            {'id' in formData && (
                isTimerActive ? 
                <button onClick={handleStopTimer} className="px-4 py-2 bg-red-600 hover:bg-red-500 rounded text-white font-semibold text-sm">Parar Timer</button>
                :
                <button onClick={handleStartTimer} disabled={userStatus !== 'in'} className="px-4 py-2 bg-green-600 hover:bg-green-500 rounded text-white font-semibold text-sm disabled:bg-gray-500 disabled:cursor-not-allowed">Iniciar Timer</button>
            )}
        </div>

        {'id' in formData && (
            <div className="mt-4 flex-grow overflow-y-auto">
                <h4 className="text-lg font-semibold text-primary mb-2">Subtarefas</h4>
                <div className="space-y-2">
                    {subtasks.map(st => <div key={st.id} className="text-sm text-secondary bg-tertiary p-2 rounded">{st.title}</div>)}
                </div>
                 <div className="flex gap-2 mt-2">
                    <input value={newSubtaskTitle} onChange={e => setNewSubtaskTitle(e.target.value)} placeholder="Nova subtarefa..." className="flex-grow bg-tertiary p-2 rounded text-sm text-primary border border-border-color" />
                    <button onClick={handleAddSubtask} className="px-3 bg-cyan-600 text-white rounded">+</button>
                </div>
            </div>
        )}

        <div className="flex justify-between items-center mt-6 pt-4 border-t border-border-color flex-shrink-0">
            <div>
                 {'id' in formData && <button onClick={() => setConfirmOpen(true)} className="px-4 py-2 text-red-400 hover:text-red-300 text-sm font-medium">Excluir Tarefa</button>}
                 {'id' in formData && <button onClick={handleFinalize} className="ml-2 px-4 py-2 text-green-400 hover:text-green-300 text-sm font-medium">Finalizar Tarefa</button>}
            </div>
            <div className="space-x-2">
                <button onClick={onClose} className="px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded text-sm text-white">Cancelar</button>
                <button onClick={handleSave} className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 rounded text-sm text-white font-semibold">Salvar</button>
            </div>
        </div>
      </div>
    </div>
    <ConfirmDialog 
        isOpen={isConfirmOpen}
        title="Excluir Tarefa"
        message="Tem certeza que deseja excluir esta tarefa e todas as suas subtarefas?"
        onConfirm={handleDelete}
        onCancel={() => setConfirmOpen(false)}
    />
    </>
  );
};

export default TaskDetailModal;
