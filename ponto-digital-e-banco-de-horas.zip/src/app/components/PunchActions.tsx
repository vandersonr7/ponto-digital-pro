
import React from 'react';
import type { UserStatus, PunchType } from '../types';

interface PunchActionsProps {
  status: UserStatus;
  onPunch: (type: PunchType) => void;
}

const ClockInIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>
);
const ClockOutIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>
);
const CoffeeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);

const PunchButton: React.FC<{ onClick: () => void; disabled: boolean; className: string; children: React.ReactNode }> = ({ onClick, disabled, className, children }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`w-full flex items-center justify-center text-lg font-semibold py-3 px-6 rounded-lg transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-opacity-50 disabled:opacity-40 disabled:cursor-not-allowed ${className}`}
  >
    {children}
  </button>
);


const PunchActions: React.FC<PunchActionsProps> = ({ status, onPunch }) => {
  return (
    <div className="w-full max-w-sm space-y-4">
      <PunchButton
        onClick={() => onPunch('in')}
        disabled={status !== 'out'}
        className="bg-green-600 hover:bg-green-500 text-white shadow-lg hover:shadow-green-500/50 focus:ring-green-400"
      >
        <ClockInIcon /> Bater Ponto (Entrada)
      </PunchButton>

      <div className="grid grid-cols-2 gap-4">
        <PunchButton
          onClick={() => onPunch('break_start')}
          disabled={status !== 'in'}
          className="bg-yellow-500 hover:bg-yellow-400 text-gray-900 shadow-lg hover:shadow-yellow-500/50 focus:ring-yellow-300"
        >
          <CoffeeIcon /> Pausa
        </PunchButton>

        <PunchButton
          onClick={() => onPunch('break_end')}
          disabled={status !== 'on_break'}
          className="bg-blue-500 hover:bg-blue-400 text-white shadow-lg hover:shadow-blue-500/50 focus:ring-blue-300"
        >
          <CoffeeIcon /> Voltar
        </PunchButton>
      </div>

      <PunchButton
        onClick={() => onPunch('out')}
        disabled={status !== 'in'}
        className="bg-red-600 hover:bg-red-500 text-white shadow-lg hover:shadow-red-500/50 focus:ring-red-400"
      >
        <ClockOutIcon /> Bater Ponto (Saída)
      </PunchButton>
    </div>
  );
};

export default PunchActions;
