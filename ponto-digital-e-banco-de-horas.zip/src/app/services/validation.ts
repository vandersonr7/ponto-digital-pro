
import { WorkSchedule, User, Client } from "../types";

export const validateEmail = (email: string): boolean => {
  if (!email) return false;
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
};

export const validatePassword = (password: string): boolean => {
  // min 6 chars, 1 uppercase, 1 number
  if (!password) return false;
  const re = /^(?=.*[A-Z])(?=.*\d).{6,}$/;
  return re.test(password);
};

export const validatePhone = (phone: string): boolean => {
  if (!phone) return true; // Optional field
  const re = /^\d{10,11}$/; // Simple check for 10 or 11 digits
  return re.test(phone);
};

export const validateURL = (url: string): boolean => {
  if (!url) return true; // Optional field
  try {
    new URL(url);
    return true;
  } catch (_) {
    return false;
  }
};

export const validateRequiredField = (field: string | number): boolean => {
  return field !== null && field !== undefined && String(field).trim() !== '';
};

export const validateSalary = (salary: number): boolean => {
  return !isNaN(salary) && salary >= 0;
};

export const validateWorkingHours = (schedule: WorkSchedule): boolean => {
  if (!schedule.start || !schedule.end) return false;
  return schedule.end > schedule.start;
};


// --- Object Validators ---
type ValidationResult = { isValid: boolean; errors: Record<string, string> };

export const validateUser = (user: User | Omit<User, 'id' | 'organizationId'>): ValidationResult => {
    const errors: Record<string, string> = {};
    if (!validateRequiredField(user.name)) errors.name = "Nome é obrigatório.";
    if (!validateEmail(user.email)) errors.email = "E-mail inválido.";
    if (!('id' in user) && !validateRequiredField(user.password || '')) errors.password = "Senha é obrigatória.";
    if (user.password && !validatePassword(user.password)) errors.password = "Senha: min 6 chars, 1 maiúscula, 1 número.";
    if (user.monthlySalary && !validateSalary(user.monthlySalary)) errors.monthlySalary = "Salário deve ser positivo.";
    if (!user.schedule || user.schedule.length < 2 || !validateWorkingHours(user.schedule[0]) || !validateWorkingHours(user.schedule[1])) {
        errors.schedule = "O horário final deve ser maior que o inicial para ambos os turnos.";
    }
    return { isValid: Object.keys(errors).length === 0, errors };
};

export const validateClient = (client: Client | Omit<Client, 'id' | 'organizationId'>): ValidationResult => {
    const errors: Record<string, string> = {};
    if (!validateRequiredField(client.companyName)) errors.companyName = "Nome da empresa é obrigatório.";
    if (client.email && !validateEmail(client.email)) errors.email = "E-mail inválido.";
    return { isValid: Object.keys(errors).length === 0, errors };
};
