
import { supabaseUrl, supabaseAnonKey } from './supabaseClient';
import { User } from '../types';

export interface SupabaseSession {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
  user: {
    id: string;
    email: string;
    [key: string]: any;
  };
}

const SESSION_STORAGE_KEY = 'supabase.auth.session';

// --- Auth State Change Emitter ---
type AuthListener = (session: SupabaseSession | null) => void;
let listeners: AuthListener[] = [];

const notifyListeners = (session: SupabaseSession | null) => {
  listeners.forEach(listener => listener(session));
};

export const onAuthStateChange = (callback: AuthListener): { unsubscribe: () => void } => {
  listeners.push(callback);
  // Adiciona um listener para eventos de storage para sincronizar entre abas
  const storageListener = (event: StorageEvent) => {
    if (event.key === SESSION_STORAGE_KEY) {
      callback(getSessionFromStorage());
    }
  };
  window.addEventListener('storage', storageListener);

  return {
    unsubscribe: () => {
      listeners = listeners.filter(l => l !== callback);
      window.removeEventListener('storage', storageListener);
    },
  };
};

export const getSessionFromStorage = (): SupabaseSession | null => {
  try {
    const sessionStr = localStorage.getItem(SESSION_STORAGE_KEY);
    return sessionStr ? JSON.parse(sessionStr) : null;
  } catch (error) {
    console.error("Could not parse session from localStorage", error);
    localStorage.removeItem(SESSION_STORAGE_KEY);
    return null;
  }
};

// --- API Functions ---

export const login = async (email: string, pass: string): Promise<SupabaseSession | null> => {
  try {
    const response = await fetch(`${supabaseUrl}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: {
        'apikey': supabaseAnonKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password: pass }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error_description || 'Login failed');
    }

    const session: SupabaseSession = await response.json();
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    notifyListeners(session);
    return session;

  } catch (error) {
    console.error('Error logging in:', error);
    return null;
  }
};

export const logout = async (): Promise<void> => {
  const session = getSessionFromStorage();
  if (session?.access_token) {
    try {
      await fetch(`${supabaseUrl}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': `Bearer ${session.access_token}`,
        },
      });
    } catch (error) {
      console.error('Supabase logout request failed, proceeding with local logout:', error);
    }
  }
  // Always clear local session and notify listeners
  localStorage.removeItem(SESSION_STORAGE_KEY);
  notifyListeners(null);
};

export const getUserProfile = async (userId: string, accessToken: string): Promise<User | null> => {
  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/users?id=eq.${userId}&select=*`, {
      method: 'GET',
      headers: {
        'apikey': supabaseAnonKey,
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/vnd.pgrst.object+json' // Request a single object
      },
    });
    
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to fetch user profile');
    }
    
    const profile = await response.json();
    return profile as User;

  } catch (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }
};
