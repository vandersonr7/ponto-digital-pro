
export const supabaseUrl = 'https://wiqejhlvxaxgansipsln.supabase.co';
// WARNING: This key is visible in the client-side code.
// Use Row Level Security (RLS) in Supabase to protect your data.
export const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndpcWVqaGx2eGF4Z2Fuc2lwc2xuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTY0ODQ2OTEsImV4cCI6MjAzMjA2MDY5MX0.Lx-sS-q1g_4kNm1-pX0RTD0-35-CF3eNyec23yt_DEs';
