
import { User, AppSettings, Punch, JobTitle, Client, ServiceType, Workspace, Board, KanbanStage, Task, AuditLog, Organization } from '../types';
import { uuid } from '../utils/uuid';

declare const dcodeIO: any;

// --- CHAVE DE ARMAZENAMENTO PRINCIPAL PARA SaaS ---
const SaaS_DATA_KEY = 'PONTO_PRO_SaaS_DATA_V2'; // V2 for UUID migration

// --- Tipos para a estrutura de dados ---
export type OrganizationData = {
    users: User[];
    jobTitles: JobTitle[];
    clients: Client[];
    serviceTypes: ServiceType[];
    workspaces: Workspace[];
    boards: Board[];
    stages: KanbanStage[];
    tasks: Task[];
    punches: { [userId: string]: { [date: string]: Punch[] } };
    auditLog: AuditLog[];
};

export type SaaSData = {
    organizations: Organization[];
    data: {
        [organizationId: string]: OrganizationData;
    }
};

const saltRounds = 10;

// --- FUNÇÕES DE ACESSO A DADOS ---
const getSaaSData = (): SaaSData => {
    const data = localStorage.getItem(SaaS_DATA_KEY);
    return data ? JSON.parse(data) : { organizations: [], data: {} };
};

const saveSaaSData = (saasData: SaaSData) => {
    localStorage.setItem(SaaS_DATA_KEY, JSON.stringify(saasData));
};

const getOrganizationData = (orgId: string): OrganizationData | undefined => {
    return getSaaSData().data[orgId];
};

const saveOrganizationData = (orgId: string, orgData: OrganizationData) => {
    const saasData = getSaaSData();
    saasData.data[orgId] = orgData;
    saveSaaSData(saasData);
};


// --- INICIALIZAÇÃO DE DADOS PADRÃO ---
const initData = () => {
    if (localStorage.getItem(SaaS_DATA_KEY)) {
        return;
    }

    const salt = dcodeIO.bcrypt.genSaltSync(saltRounds);
    
    const platformOrgId = '0';
    const exampleOrgId = uuid();
    
    const superAdmin: User = { 
        id: uuid(), organizationId: platformOrgId, name: 'Super Admin', email: 'admin@email.com', 
        password: dcodeIO.bcrypt.hashSync('admin', salt), role: 'superadmin', jobTitle: 'Platform Owner', 
        schedule: [], monthlySalary: 0 
    };

    const exampleOrg: Organization = { id: exampleOrgId, name: 'Empresa Exemplo' };

    const orgAdmin: User = { 
        id: uuid(), organizationId: exampleOrgId, name: 'Admin da Empresa', email: 'empresa@email.com',
        password: dcodeIO.bcrypt.hashSync('admin', salt), role: 'admin', jobTitle: 'Administrador',
        schedule: [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '18:00' }],
        monthlySalary: 10000
    };
    
    const exampleEmployee: User = {
        id: uuid(), organizationId: exampleOrgId, name: 'Funcionário Teste', email: 'func@email.com',
        password: dcodeIO.bcrypt.hashSync('func', salt), role: 'employee', jobTitle: 'Desenvolvedor',
        schedule: [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '18:00' }],
        monthlySalary: 5000
    };

    const client1: Client = {
        id: uuid(), organizationId: exampleOrgId, companyName: 'Cliente Exemplo S.A.', logoUrl: '', fullAddress: 'Rua Exemplo, 123',
        phone: '11999998888', email: 'contato@cliente.com', whatsapp: '11999998888',
        responsiblePerson: 'João da Silva', observation: 'Cliente prioritário.'
    };

    const service1: ServiceType = { id: uuid(), organizationId: exampleOrgId, name: 'Desenvolvimento Web', hourlyRate: 150 };
    const workspace1: Workspace = { id: uuid(), organizationId: exampleOrgId, name: 'Projetos de Clientes', adminOnly: false };
    const board1: Board = { id: uuid(), organizationId: exampleOrgId, name: 'Website Corporativo', workspaceId: workspace1.id };
    
    const stage1: KanbanStage = { id: uuid(), organizationId: exampleOrgId, name: 'A Fazer', boardId: board1.id, order: 0 };
    const stage2: KanbanStage = { id: uuid(), organizationId: exampleOrgId, name: 'Em Andamento', boardId: board1.id, order: 1 };

    const exampleOrgData: OrganizationData = {
        users: [orgAdmin, exampleEmployee],
        jobTitles: [ { id: uuid(), organizationId: exampleOrgId, name: 'Administrador' }, { id: uuid(), organizationId: exampleOrgId, name: 'Desenvolvedor' } ],
        clients: [client1],
        serviceTypes: [service1],
        workspaces: [workspace1],
        boards: [board1],
        stages: [stage1, stage2],
        tasks: [{ 
            id: uuid(), organizationId: exampleOrgId, title: 'Desenvolver Landing Page', description: '', stageId: stage1.id, boardId: board1.id,
            clientId: client1.id, serviceTypeId: service1.id, assignedUserId: exampleEmployee.id, timeSpentSeconds: 0, activeTimerStartTime: null 
        }],
        punches: {},
        auditLog: []
    };
    
    const initialSaaSData: SaaSData = {
        organizations: [exampleOrg],
        data: {
            [platformOrgId]: { 
                users: [superAdmin],
                jobTitles: [], clients: [], serviceTypes: [], workspaces: [], boards: [], stages: [], tasks: [], punches: {}, auditLog: []
            },
            [exampleOrgId]: exampleOrgData
        }
    };
    
    saveSaaSData(initialSaaSData);
    
    if (!localStorage.getItem('digital_punch_settings')) {
      localStorage.setItem('digital_punch_settings', JSON.stringify({
        appName: 'Ponto Digital Pro',
        appLogoUrl: 'https://tailwindui.com/img/logos/mark.svg?color=cyan&shade=400',
        appFaviconUrl: 'https://tailwindui.com/img/logos/mark.svg?color=cyan&shade=400',
        companyHours: [{ start: '08:00', end: '12:00' }, { start: '13:00', end: '17:00' }],
      }));
    }
};

initData();

// --- FUNÇÕES GENÉRICAS DE CRUD (AGORA COM CONTEXTO DE ORGANIZAÇÃO) ---
export const getItems = <T>(orgId: string, key: keyof OrganizationData): T[] => {
    const orgData = getOrganizationData(orgId);
    return (orgData?.[key] as T[] | undefined) || [];
};
export const saveItems = <T>(orgId: string, key: keyof OrganizationData, items: T[]) => {
    const orgData = getOrganizationData(orgId);
    if (orgData) {
        (orgData[key] as T[]) = items;
        saveOrganizationData(orgId, orgData);
    }
};
export const addItem = <T extends {id: string, organizationId: string}>(orgId: string, key: keyof OrganizationData, itemData: Omit<T, 'id' | 'organizationId'>): T => {
    const items = getItems<T>(orgId, key);
    const newItem = { ...itemData, id: uuid(), organizationId: orgId } as T;
    saveItems(orgId, key, [...items, newItem]);
    return newItem;
};
export const updateItem = <T extends {id: string, organizationId: string}>(orgId: string, key: keyof OrganizationData, updatedItem: T): T => {
    const items = getItems<T>(orgId, key);
    const index = items.findIndex(item => item.id === updatedItem.id);
    if (index !== -1) {
        items[index] = updatedItem;
        saveItems(orgId, key, items);
    }
    return updatedItem;
};
export const deleteItem = <T extends {id: string}>(orgId: string, key: keyof OrganizationData, itemId: string) => {
    saveItems(orgId, key, getItems<T & {id: string}>(orgId, key).filter(item => item.id !== itemId));
};

// --- Raw Data Access for specific complex types ---
export const getRawOrganizationData = (orgId: string) => getOrganizationData(orgId);
export const saveRawOrganizationData = (orgId: string, orgData: OrganizationData) => saveOrganizationData(orgId, orgData);
export const getRawSaaSData = () => getSaaSData();
export const saveRawSaaSData = (data: SaaSData) => saveSaaSData(data);


// --- Settings (non-organizational) ---
export const getSettings = (): AppSettings => JSON.parse(localStorage.getItem('digital_punch_settings') || '{}');
export const saveSettings = (settings: AppSettings) => localStorage.setItem('digital_punch_settings', JSON.stringify(settings));
