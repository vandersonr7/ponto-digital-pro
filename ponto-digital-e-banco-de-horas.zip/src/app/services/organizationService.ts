
import { Organization, User } from '../types';
import * as storage from './storage';
import { uuid } from '../utils/uuid';

declare const dcodeIO: any;
const saltRounds = 10;

type OrganizationData = storage.OrganizationData;

export const getOrganizations = (): Organization[] => {
    return storage.getRawSaaSData().organizations;
};

export const addOrganizationAndAdmin = (orgName: string, adminUser: Omit<User, 'id' | 'organizationId' | 'role'>): void => {
    const saasData = storage.getRawSaaSData();
    const newOrgId = uuid();
    
    const newOrg: Organization = { id: newOrgId, name: orgName };
    saasData.organizations.push(newOrg);

    const salt = dcodeIO.bcrypt.genSaltSync(saltRounds);
    const hashedPassword = dcodeIO.bcrypt.hashSync(adminUser.password!, salt);

    const newAdmin: User = {
        ...adminUser,
        password: hashedPassword,
        id: uuid(),
        organizationId: newOrgId,
        role: 'admin',
        schedule: [{ start: '09:00', end: '18:00' }],
    };

    const newOrgData: NonNullable<OrganizationData> = {
        users: [newAdmin],
        clients: [], jobTitles: [], serviceTypes: [], workspaces: [],
        boards: [], stages: [], tasks: [], punches: {}, auditLog: []
    };
    saasData.data[newOrgId] = newOrgData;

    storage.saveRawSaaSData(saasData);
};
