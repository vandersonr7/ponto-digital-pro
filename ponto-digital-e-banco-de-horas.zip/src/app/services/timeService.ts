
import { Punch, User } from '../types';
import * as storage from './storage';

export const getPunchesForUser = (orgId: string, userId: string): Punch[] => {
    const orgData = storage.getRawOrganizationData(orgId);
    if (!orgData) return [];
    const today = new Date().toISOString().split('T')[0];
    const userPunches = orgData.punches[userId] || {};
    return (userPunches[today] || []).map((p: any) => ({...p, timestamp: new Date(p.timestamp)}));
};

export const savePunchForUser = (orgId: string, userId: string, punch: Punch): void => {
    const orgData = storage.getRawOrganizationData(orgId);
    if (!orgData) return;
    const today = new Date().toISOString().split('T')[0];
    if (!orgData.punches[userId]) orgData.punches[userId] = {};
    if (!orgData.punches[userId][today]) orgData.punches[userId][today] = [];
    orgData.punches[userId][today].push(punch);
    storage.saveRawOrganizationData(orgId, orgData);
};

export const getAllPunchesForToday = (orgId: string): { user: User; punches: Punch[] }[] => {
    const users = storage.getItems<User>(orgId, 'users');
    const orgData = storage.getRawOrganizationData(orgId);
    if (!orgData) return [];
    const todayStr = new Date().toISOString().split('T')[0];
    return users.map(user => {
        const userPunchesToday = (orgData.punches[user.id]?.[todayStr] || []).map((p: any) => ({...p, timestamp: new Date(p.timestamp)}));
        return { user, punches: userPunchesToday };
    });
};
