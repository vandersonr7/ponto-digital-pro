
// FIX: Add a global declaration for `window.jspdf` to inform TypeScript that this property exists, which is added by the jsPDF library script.
declare global {
  interface Window {
    jspdf: any;
  }
}
declare const jsPDF: any;
declare const XLSX: any;

export const exportToPDF = (title: string, headers: string[][], data: (string | number)[][], logoUrl: string) => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  
  // Header
  if (logoUrl) {
    // You might need to handle CORS for the logo image
    // For simplicity, this assumes the URL is accessible
    // const img = new Image();
    // img.src = logoUrl;
    // img.onload = () => {
    //   doc.addImage(img, 'PNG', 10, 10, 30, 10);
    // };
  }
  doc.setFontSize(18);
  doc.text(title, 14, 22);
  doc.setFontSize(11);
  doc.setTextColor(100);
  doc.text(`Relatório gerado em: ${new Date().toLocaleDateString('pt-BR')}`, 14, 30);

  // Table
  doc.autoTable({
    head: headers,
    body: data,
    startY: 35,
    theme: 'grid',
    styles: {
        fontSize: 9,
        cellPadding: 2,
    },
    headStyles: {
        fillColor: [37, 41, 51], // gray-700
        textColor: 240,
        fontStyle: 'bold',
    },
  });

  doc.save(`${title.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
};

export const exportToExcel = (fileName: string, sheets: { sheetName: string, data: any[] }[]) => {
  const wb = XLSX.utils.book_new();
  sheets.forEach(sheet => {
    const ws = XLSX.utils.json_to_sheet(sheet.data);
    XLSX.utils.book_append_sheet(wb, ws, sheet.sheetName);
  });
  XLSX.writeFile(wb, `${fileName}_${new Date().toISOString().split('T')[0]}.xlsx`);
};