
import { AppSettings, JobTitle, Client, ServiceType } from '../types';
import * as storage from './storage';
import { validateClient } from './validation';

// --- Global App Settings ---
export const getSettings = (): AppSettings => storage.getSettings();
export const saveSettings = (settings: AppSettings): AppSettings => {
  storage.saveSettings(settings);
  return settings;
};

// --- Job Titles ---
export const getJobTitles = (orgId: string): JobTitle[] => storage.getItems<JobTitle>(orgId, 'jobTitles');
export const addJobTitle = (orgId: string, newTitle: Omit<JobTitle, 'id'|'organizationId'>): JobTitle => storage.addItem<JobTitle>(orgId, 'jobTitles', newTitle);
export const updateJobTitle = (orgId: string, updatedJobTitle: JobTitle): JobTitle => storage.updateItem<JobTitle>(orgId, 'jobTitles', updatedJobTitle);
export const deleteJobTitle = (orgId: string, id: string): void => storage.deleteItem<JobTitle>(orgId, 'jobTitles', id);

// --- Clients ---
export const getClients = (orgId: string): Client[] => storage.getItems<Client>(orgId, 'clients');
export const addClient = (orgId: string, newClient: Omit<Client, 'id'|'organizationId'>): Client => {
    const { isValid } = validateClient(newClient);
    if (!isValid) throw new Error("Dados do cliente inválidos.");
    return storage.addItem<Client>(orgId, 'clients', newClient);
};
export const updateClient = (orgId: string, updatedClient: Client): Client => {
    const { isValid } = validateClient(updatedClient);
    if (!isValid) throw new Error("Dados do cliente inválidos.");
    return storage.updateItem<Client>(orgId, 'clients', updatedClient);
};
export const deleteClient = (orgId: string, id: string): void => storage.deleteItem<Client>(orgId, 'clients', id);

// --- Service Types ---
export const getServiceTypes = (orgId: string): ServiceType[] => storage.getItems<ServiceType>(orgId, 'serviceTypes');
export const addServiceType = (orgId: string, newService: Omit<ServiceType, 'id'|'organizationId'>): ServiceType => storage.addItem<ServiceType>(orgId, 'serviceTypes', newService);
export const updateServiceType = (orgId: string, updatedService: ServiceType): ServiceType => storage.updateItem<ServiceType>(orgId, 'serviceTypes', updatedService);
export const deleteServiceType = (orgId: string, id: string): void => storage.deleteItem<ServiceType>(orgId, 'serviceTypes', id);
