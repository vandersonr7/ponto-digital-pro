
import { Workspace, Board, KanbanStage, Task } from '../types';
import * as storage from './storage';

// Workspaces
export const getWorkspaces = (orgId: string): Workspace[] => storage.getItems<Workspace>(orgId, 'workspaces');
export const addWorkspace = (orgId: string, newWorkspace: Omit<Workspace, 'id'|'organizationId'>): Workspace => storage.addItem<Workspace>(orgId, 'workspaces', newWorkspace);
export const updateWorkspace = (orgId: string, updatedWorkspace: Workspace): Workspace => storage.updateItem<Workspace>(orgId, 'workspaces', updatedWorkspace);
export const deleteWorkspace = (orgId: string, workspaceId: string): void => {
    const allBoards = getBoards(orgId);
    const boardIdsToDelete = allBoards.filter(b => b.workspaceId === workspaceId).map(b => b.id);
    boardIdsToDelete.forEach(boardId => deleteBoard(orgId, boardId));
    storage.deleteItem<Workspace>(orgId, 'workspaces', workspaceId);
};

// Boards
export const getBoards = (orgId: string): Board[] => storage.getItems<Board>(orgId, 'boards');
export const addBoard = (orgId: string, newBoard: Omit<Board, 'id'|'organizationId'>): Board => storage.addItem<Board>(orgId, 'boards', newBoard);
export const updateBoard = (orgId: string, updatedBoard: Board): Board => storage.updateItem<Board>(orgId, 'boards', updatedBoard);
export const deleteBoard = (orgId: string, boardId: string): void => {
    const allStages = getStages(orgId).filter(s => s.boardId === boardId);
    allStages.forEach(stage => deleteStage(orgId, stage.id));
    const remainingTasks = getTasks(orgId).filter(t => t.boardId !== boardId);
    storage.saveItems(orgId, 'tasks', remainingTasks);
    storage.deleteItem<Board>(orgId, 'boards', boardId);
};

// Stages
export const getStages = (orgId: string): KanbanStage[] => storage.getItems<KanbanStage>(orgId, 'stages');
export const saveStages = (orgId: string, stages: KanbanStage[]): void => storage.saveItems(orgId, 'stages', stages);
export const addStage = (orgId: string, newStage: Omit<KanbanStage, 'id'|'organizationId'>): KanbanStage => storage.addItem<KanbanStage>(orgId, 'stages', newStage);
export const updateStage = (orgId: string, updatedStage: KanbanStage): KanbanStage => storage.updateItem<KanbanStage>(orgId, 'stages', updatedStage);
export const deleteStage = (orgId: string, stageId: string): void => {
    const remainingTasks = getTasks(orgId).filter(t => t.stageId !== stageId);
    storage.saveItems(orgId, 'tasks', remainingTasks);
    storage.deleteItem<KanbanStage>(orgId, 'stages', stageId);
};

// Tasks
export const getTasks = (orgId: string): Task[] => storage.getItems<Task>(orgId, 'tasks');
export const addTask = (orgId: string, newTaskData: Omit<Task, 'id'|'organizationId'>): Task => {
    const taskDefaults = { timeSpentSeconds: 0, activeTimerStartTime: null };
    return storage.addItem<Task>(orgId, 'tasks', {...taskDefaults, ...newTaskData});
};
export const updateTask = (orgId: string, updatedTask: Task): Task => storage.updateItem<Task>(orgId, 'tasks', updatedTask);
export const deleteTask = (orgId: string, taskId: string): void => {
    let tasks = getTasks(orgId);
    const tasksToDelete = new Set<string>([taskId]);
    let foundNew = true;
    while(foundNew) {
        foundNew = false;
        tasks.forEach(task => {
            if (task.parentId && tasksToDelete.has(task.parentId) && !tasksToDelete.has(task.id)) {
                tasksToDelete.add(task.id);
                foundNew = true;
            }
        });
    }
    const remainingTasks = tasks.filter(task => !tasksToDelete.has(task.id));
    storage.saveItems(orgId, 'tasks', remainingTasks);
};
