
import { User } from '../types';
import * as storage from './storage';
import { validateUser } from './validation';

declare const dcodeIO: any;
const saltRounds = 10;

export const getUsers = (orgId: string): User[] => storage.getItems<User>(orgId, 'users');

export const addUser = (orgId: string, newUser: Omit<User, 'id' | 'organizationId'>): User => {
    const { isValid } = validateUser(newUser);
    if (!isValid) throw new Error("Dados de usuário inválidos.");

    const salt = dcodeIO.bcrypt.genSaltSync(saltRounds);
    const hashedPassword = dcodeIO.bcrypt.hashSync(newUser.password!, salt);
    return storage.addItem<User>(orgId, 'users', { ...newUser, password: hashedPassword });
};

export const updateUser = (orgId: string, updatedUser: User): User => {
    const { isValid } = validateUser(updatedUser);
    if (!isValid) throw new Error("Dados de usuário inválidos.");

    const users = getUsers(orgId);
    const currentUser = users.find(u => u.id === updatedUser.id);

    if (currentUser) {
        if (updatedUser.password && updatedUser.password.length > 0) {
            const salt = dcodeIO.bcrypt.genSaltSync(saltRounds);
            updatedUser.password = dcodeIO.bcrypt.hashSync(updatedUser.password, salt);
        } else {
            updatedUser.password = currentUser.password;
        }
    }
    return storage.updateItem<User>(orgId, 'users', updatedUser);
};

export const deleteUser = (orgId: string, userId: string): void => {
    storage.deleteItem<User>(orgId, 'users', userId);
    const orgData = storage.getRawOrganizationData(orgId);
    if (orgData && orgData.punches[userId]) {
        delete orgData.punches[userId];
        storage.saveRawOrganizationData(orgId, orgData);
    }
};

export const findUserByEmail = (email: string): User | undefined => {
    const saasData = storage.getRawSaaSData();
    for (const orgId in saasData.data) {
        const user = saasData.data[orgId].users.find(u => u.email.toLowerCase() === email.toLowerCase());
        if (user) return user;
    }
    return undefined;
};
