
import { AuditLog } from '../types';
import * as storage from './storage';

export const getAuditLogs = (orgId: string): AuditLog[] => {
  return storage.getItems<AuditLog>(orgId, 'auditLog').map(log => ({...log, timestamp: new Date(log.timestamp)}));
};

export const addAuditLog = (orgId: string, log: Omit<AuditLog, 'id' | 'organizationId' | 'timestamp'>): AuditLog => {
  return storage.addItem<AuditLog>(orgId, 'auditLog', { ...log, timestamp: new Date() });
};
