
import React, { createContext, useContext, ReactNode } from 'react';
import { addAuditLog } from '../services/auditService';
import { useSession } from './SessionContext';

type ActionType = 'Login' | 'Logout' | 'Create' | 'Update' | 'Delete' | 'Move Task' | 'Finalize Task' | 'Create Stage' | 'Update Stage' | 'Delete Stage' | 'Create Subtask';

interface AuditContextType {
  logAction: (action: ActionType, details: string) => void;
}

const AuditContext = createContext<AuditContextType | undefined>(undefined);

export const AuditProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useSession();

  const logAction = (action: ActionType, details: string) => {
    if (user) {
      addAuditLog(user.organizationId, {
        userId: user.id,
        userName: user.name,
        action,
        details,
      });
    }
  };

  return (
    <AuditContext.Provider value={{ logAction }}>
      {children}
    </AuditContext.Provider>
  );
};

export const useAudit = () => {
  const context = useContext(AuditContext);
  if (!context) {
    throw new Error('useAudit must be used within an AuditProvider');
  }
  return context;
};
