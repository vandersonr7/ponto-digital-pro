
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { User, Task } from '../types';
import * as supabaseApi from '../services/supabaseApi';
import type { SupabaseSession } from '../services/supabaseApi';
import * as projectService from '../services/projectService';


interface AuthContextType {
  user: User | null;
  login: (email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  updateCurrentUser: (user: User) => void;
  activeTask: Task | null;
  setActiveTask: (task: Task | null) => void;
  setUser: (user: User | null) => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTask, setActiveTaskState] = useState<Task | null>(null);
  const [loading, setLoading] = useState(true);

  const setActiveTask = (task: Task | null) => {
    if (activeTask && (!task || activeTask.id !== task.id)) {
      const now = Date.now();
      const startTime = activeTask.activeTimerStartTime || now;
      const elapsed = now - startTime;
      const updatedOldTask = {
        ...activeTask,
        timeSpentSeconds: activeTask.timeSpentSeconds + Math.round(elapsed / 1000),
        activeTimerStartTime: null,
      };
      projectService.updateTask(activeTask.organizationId, updatedOldTask);
    }
    setActiveTaskState(task);
  };
  
  useEffect(() => {
    setLoading(true);

    const handleSession = async (session: SupabaseSession | null) => {
      if (session && session.user) {
        const profile = await supabaseApi.getUserProfile(session.user.id, session.access_token);
        if (profile) {
            const { password, ...userToStore } = profile;
            setUser(userToStore);

            const allTasks = projectService.getTasks(profile.organizationId);
            const previouslyActive = allTasks.find(t => t.assignedUserId === profile.id && t.activeTimerStartTime);
            if (previouslyActive) {
                setActiveTaskState(previouslyActive);
            }
        } else {
            setUser(null);
            await supabaseApi.logout();
        }
      } else {
        setUser(null);
        setActiveTaskState(null);
      }
      setLoading(false);
    };

    // Check for session in storage on initial load
    const initialSession = supabaseApi.getSessionFromStorage();
    handleSession(initialSession);

    // Listen for future auth changes
    const { unsubscribe } = supabaseApi.onAuthStateChange(handleSession);
    
    return () => {
      unsubscribe();
    };
  }, []);

  const login = async (email: string, pass: string): Promise<boolean> => {
    const session = await supabaseApi.login(email, pass);
    return !!session;
  };

  const logout = async () => {
    if (activeTask) {
      setActiveTask(null); 
    }
    await supabaseApi.logout();
    sessionStorage.removeItem('sessionStart');
  };
  
  const updateCurrentUser = (updatedUser: User) => {
    const { password, ...userToStore } = updatedUser;
    setUser(userToStore);
  }

  const value = { user, login, logout, updateCurrentUser, activeTask, setActiveTask, setUser };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
