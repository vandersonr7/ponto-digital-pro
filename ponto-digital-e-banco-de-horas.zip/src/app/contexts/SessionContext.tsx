
import React, { createContext, useContext, ReactNode } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useSessionTimeout } from '../hooks/useSessionTimeout';
import { User } from '../types';

interface SessionContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  updateCurrentUser: (user: User) => void;
}

const SessionContext = createContext<SessionContextType | undefined>(undefined);

export const SessionProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user, login, logout, updateCurrentUser } = useAuth();
  
  const handleTimeout = () => {
    if (user) { // Only logout if there's an active user
      logout();
      console.log("Session expired due to inactivity.");
    }
  };

  useSessionTimeout(handleTimeout);

  return (
    <SessionContext.Provider value={{ user, isAuthenticated: !!user, login, logout, updateCurrentUser }}>
      {children}
    </SessionContext.Provider>
  );
};

export const useSession = () => {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error('useSession must be used within a SessionProvider');
  }
  return context;
};
