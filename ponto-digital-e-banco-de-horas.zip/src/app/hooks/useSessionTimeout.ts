
import { useEffect, useCallback } from 'react';

const SESSION_TIMEOUT_MS = 8 * 60 * 60 * 1000; // 8 hours
const EVENTS_TO_MONITOR = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];

export const useSessionTimeout = (onTimeout: () => void) => {
  const resetTimer = useCallback(() => {
    sessionStorage.setItem('sessionStart', Date.now().toString());
  }, []);

  useEffect(() => {
    let timeoutId: number;

    const checkTimeout = () => {
      const sessionStart = parseInt(sessionStorage.getItem('sessionStart') || '0', 10);
      if (!sessionStart || Date.now() - sessionStart > SESSION_TIMEOUT_MS) {
        onTimeout();
      }
    };

    const handleActivity = () => {
      resetTimer();
    };

    // Set initial timer
    resetTimer();

    // Add event listeners for user activity
    EVENTS_TO_MONITOR.forEach(event => {
      window.addEventListener(event, handleActivity);
    });

    // Set interval to check for timeout periodically
    timeoutId = window.setInterval(checkTimeout, 60 * 1000); // Check every minute

    // Cleanup function
    return () => {
      clearInterval(timeoutId);
      EVENTS_TO_MONITOR.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [onTimeout, resetTimer]);
};