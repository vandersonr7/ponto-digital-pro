
import React, { useState } from 'react';
import { useSession } from '../contexts/SessionContext';
import { updateUser } from '../services/userService';
import { Page, User } from '../types';
import { useToast } from '../contexts/ToastContext';
import { useAudit } from '../contexts/AuditContext';
import * as validator from '../services/validation';
import LoadingSpinner from '../components/LoadingSpinner';

interface ProfilePageProps {
  navigate: (page: Page) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ navigate }) => {
  const { user, updateCurrentUser } = useSession();
  const { addToast } = useToast();
  const { logAction } = useAudit();
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  if (!user) {
    return null;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!validator.validateRequiredField(formData.name)) newErrors.name = "Nome é obrigatório.";
    if (!validator.validateEmail(formData.email)) newErrors.email = "E-mail inválido.";

    if (formData.password) {
      if (!validator.validatePassword(formData.password)) {
        newErrors.password = "Senha deve ter min. 6 chars, 1 maiúscula e 1 número.";
      } else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'As senhas não coincidem.';
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
        addToast('Por favor, corrija os erros no formulário.', 'error');
        return;
    }
    
    setLoading(true);

    const updatedUserData: User = { ...user, name: formData.name, email: formData.email };
    if (formData.password) {
        updatedUserData.password = formData.password;
    }

    setTimeout(() => {
        const savedUser = updateUser(user.organizationId, updatedUserData);
        updateCurrentUser(savedUser); 
        logAction('Update', 'O usuário atualizou o próprio perfil.');
        
        addToast('Perfil atualizado com sucesso!', 'success');
        
        setFormData(prev => ({...prev, password: '', confirmPassword: ''}));
        setLoading(false);
        
        setTimeout(() => navigate('dashboard'), 1500);
    }, 500);
  };
  
  const InputField = (props: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }) => (
    <div>
        <label className="block text-sm font-medium text-secondary">{props.label}</label>
        <input {...props} className={`w-full bg-tertiary p-2 rounded mt-1 border ${props.error ? 'border-red-500' : 'border-border-color'} focus:ring-cyan-500 focus:border-cyan-500 transition-colors`} />
        {props.error && <p className="text-xs text-red-500 mt-1">{props.error}</p>}
    </div>
  );

  return (
    <div className="w-full max-w-2xl mx-auto bg-secondary p-6 rounded-2xl shadow-lg border border-border-color">
      <h2 className="text-3xl font-bold text-cyan-400 mb-6">Meu Perfil</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <InputField label="Nome Completo" name="name" type="text" value={formData.name} onChange={handleChange} required error={errors.name} />
        <InputField label="E-mail" name="email" type="email" value={formData.email} onChange={handleChange} required error={errors.email} />
        
        <hr className="border-border-color"/>
        <p className="text-secondary/70 text-sm">Deixe os campos abaixo em branco para não alterar sua senha.</p>
        
        <InputField label="Nova Senha" name="password" type="password" value={formData.password} onChange={handleChange} error={errors.password} />
        <InputField label="Confirmar Nova Senha" name="confirmPassword" type="password" value={formData.confirmPassword} onChange={handleChange} error={errors.confirmPassword} />
        
        <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2 font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500 flex items-center justify-center disabled:opacity-50"
            >
              {loading && <LoadingSpinner />}
              Salvar Alterações
            </button>
        </div>
      </form>
    </div>
  );
};

export default ProfilePage;
