
import React, { useState } from 'react';
import { AppSettings, User, JobTitle, Client, ServiceType, Workspace } from '../types';
import { useToast } from '../contexts/ToastContext';
import * as validator from '../services/validation';
import LoadingSpinner from '../components/LoadingSpinner';
import ConfirmDialog from '../components/ConfirmDialog';
import { useAudit } from '../contexts/AuditContext';
import { useSession } from '../contexts/SessionContext';
import * as settingsService from '../services/settingsService';
import * as userService from '../services/userService';
import * as projectService from '../services/projectService';


interface SettingsPageProps {
  onSettingsUpdate: (settings: AppSettings) => void;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ onSettingsUpdate }) => {
  const [activeTab, setActiveTab] = useState('general');
  const { user } = useSession();

  if (!user || user.role !== 'admin') return null;

  const TabButton: React.FC<{tabName: string; label: string}> = ({tabName, label}) => (
    <button 
        onClick={() => setActiveTab(tabName)}
        className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors ${activeTab === tabName ? 'bg-cyan-600 text-white' : 'text-secondary hover:bg-tertiary'}`}
    >
        {label}
    </button>
  );

  return (
    <div className="w-full max-w-6xl mx-auto bg-secondary p-4 sm:p-6 rounded-2xl shadow-lg border border-border-color">
      <h2 className="text-3xl font-bold text-cyan-400 mb-6">Cadastros e Configurações</h2>
      
      <div className="mb-6 flex space-x-1 sm:space-x-2 border-b border-border-color pb-2 overflow-x-auto">
        <TabButton tabName="general" label="Geral" />
        <TabButton tabName="clients" label="Clientes" />
        <TabButton tabName="services" label="Tipos de Serviço" />
        <TabButton tabName="workspaces" label="Áreas de Trabalho" />
        <TabButton tabName="jobs" label="Cargos" />
        <TabButton tabName="employees" label="Funcionários" />
      </div>
      
      <div className="transition-opacity duration-300">
        {activeTab === 'general' && <GeneralSettings onSettingsUpdate={onSettingsUpdate} />}
        {activeTab === 'clients' && <ClientSettings orgId={user.organizationId} />}
        {activeTab === 'services' && <ServiceTypeSettings orgId={user.organizationId} />}
        {activeTab === 'workspaces' && <WorkspaceSettings orgId={user.organizationId} />}
        {activeTab === 'jobs' && <JobTitleSettings orgId={user.organizationId} />}
        {activeTab === 'employees' && <EmployeeSettings orgId={user.organizationId} />}
      </div>
    </div>
  );
};

// Common UI Components for this page
const InputField = (props: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }) => (
    <div>
        <label className="block text-sm font-medium text-secondary">{props.label}</label>
        <input {...props} className={`w-full bg-tertiary p-2 rounded mt-1 border ${props.error ? 'border-red-500' : 'border-border-color'} focus:ring-cyan-500 focus:border-cyan-500 transition-colors`} />
        {props.error && <p className="text-xs text-red-500 mt-1">{props.error}</p>}
    </div>
);
const AddButton: React.FC<{onClick: () => void; children: React.ReactNode}> = ({ onClick, children }) => (
    <button onClick={onClick} className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-md text-white font-semibold text-sm transition-colors">{children}</button>
);
const SaveButton: React.FC<{onClick: () => void, disabled?: boolean, children?: React.ReactNode}> = ({ onClick, disabled, children="Salvar" }) => (
    <button onClick={onClick} disabled={disabled} className="px-4 py-2 bg-green-600 hover:bg-green-500 rounded text-sm text-white font-semibold disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors">{children}</button>
);
const CancelButton: React.FC<{onClick: () => void}> = ({ onClick }) => (
    <button onClick={onClick} className="px-4 py-2 bg-gray-500 hover:bg-gray-400 rounded text-sm text-white font-semibold transition-colors">Cancelar</button>
);

// --- GENERAL ---
const GeneralSettings: React.FC<{onSettingsUpdate: (s: AppSettings) => void}> = ({ onSettingsUpdate }) => {
    const [settings, setSettings] = useState<AppSettings>(settingsService.getSettings());
    const [loading, setLoading] = useState(false);
    const { addToast } = useToast();
    const { logAction } = useAudit();
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setSettings(prev => ({ ...prev, [name]: value }));
    };

    const handleHoursChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const { name, value } = e.target;
        setSettings(prev => {
          const newHours = [...prev.companyHours];
          newHours[index] = { ...newHours[index], [name]: value };
          return { ...prev, companyHours: newHours };
        });
    };
    
    const handleSave = () => {
        setLoading(true);
        settingsService.saveSettings(settings);
        onSettingsUpdate(settings);
        logAction('Update', 'Configurações gerais foram atualizadas.');
        setTimeout(() => {
            addToast('Configurações salvas com sucesso!', 'success');
            setLoading(false);
        }, 500);
    };

    return (
        <div className="space-y-6">
             <div className="space-y-4">
                <InputField label="Nome do App" name="appName" value={settings.appName} onChange={handleChange} />
                <InputField label="URL da Logo" name="appLogoUrl" value={settings.appLogoUrl} onChange={handleChange} />
                <InputField label="URL do Favicon" name="appFaviconUrl" value={settings.appFaviconUrl} onChange={handleChange} />
             </div>
            <h3 className="text-xl font-semibold text-secondary pt-4 border-t border-border-color">Horário da Empresa</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(settings.companyHours || [{},{}]).map((schedule, index) => (
                    <div key={index} className="p-3 bg-tertiary rounded-md">
                        <p className="text-sm font-medium text-secondary/70 mb-2">Turno {index + 1}</p>
                        <div className="grid grid-cols-2 gap-4">
                            <InputField type="time" label="Início" name="start" value={schedule.start || ''} onChange={(e) => handleHoursChange(e, index)} />
                            <InputField type="time" label="Fim" name="end" value={schedule.end || ''} onChange={(e) => handleHoursChange(e, index)} />
                        </div>
                    </div>
                ))}
            </div>
            <button onClick={handleSave} disabled={loading} className="w-full mt-4 py-3 flex items-center justify-center bg-cyan-600 hover:bg-cyan-500 rounded-md text-white font-semibold disabled:opacity-50">
                {loading && <LoadingSpinner />}
                Salvar Configurações
            </button>
        </div>
    );
};


// --- CRUD GENERIC COMPONENT ---
interface CrudManagerProps<T extends { id: string; name?: string; companyName?: string; }> {
  orgId: string;
  title: string;
  itemName: string;
  getItems: (orgId: string) => T[];
  addItem: (orgId: string, item: Omit<T, 'id' | 'organizationId'>) => T;
  updateItem: (orgId: string, item: T) => T;
  deleteItem: (orgId: string, id: string) => void;
  renderForm: (props: { item: T | null; onSave: (item: T) => void; onCancel: () => void; }) => React.ReactNode;
  renderListItem: (item: T) => React.ReactNode;
}
const CrudManager = <T extends { id: string; name?: string; companyName?: string; }>({ orgId, title, itemName, getItems, addItem, updateItem, deleteItem, renderForm, renderListItem }: CrudManagerProps<T>) => {
    const [items, setItems] = useState<T[]>(() => getItems(orgId));
    const [editingItem, setEditingItem] = useState<T | null>(null);
    const [isConfirmOpen, setConfirmOpen] = useState(false);
    const [itemToDelete, setItemToDelete] = useState<string | null>(null);
    const { addToast } = useToast();
    const { logAction } = useAudit();
    
    const reloadItems = () => setItems(getItems(orgId));

    const handleSave = (item: T) => {
        const action = 'id' in item && item.id ? 'Update' : 'Create';
        const name = item.name || item.companyName || `ID ${item.id}`;
        if ('id' in item && item.id) {
            updateItem(orgId, item);
        } else {
            addItem(orgId, item as Omit<T, 'id' | 'organizationId'>);
        }
        logAction(action, `${itemName}: ${name}`);
        addToast(`${itemName} ${item.id ? 'atualizado' : 'adicionado'} com sucesso!`, 'success');
        setEditingItem(null);
        reloadItems();
    };

    const confirmDelete = (id: string) => { setItemToDelete(id); setConfirmOpen(true); };

    const handleDelete = () => {
        if (itemToDelete) {
            const item = items.find(i => i.id === itemToDelete);
            const name = item?.name || item?.companyName || `ID ${itemToDelete}`;
            deleteItem(orgId, itemToDelete);
            logAction('Delete', `${itemName}: ${name}`);
            addToast(`${itemName} excluído com sucesso.`, 'success');
            reloadItems();
        }
        setConfirmOpen(false);
        setItemToDelete(null);
    };

    if (editingItem) {
        return <>{renderForm({ item: editingItem, onSave: handleSave, onCancel: () => setEditingItem(null) })}</>;
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-primary">{title}</h3>
                <AddButton onClick={() => setEditingItem({} as T)}>Adicionar {itemName}</AddButton>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {items.map(item => (
                    <div key={item.id} className="bg-tertiary p-4 rounded-lg border border-border-color flex justify-between items-start">
                        <div>{renderListItem(item)}</div>
                        <div className="flex space-x-3 flex-shrink-0 ml-4">
                            <button onClick={() => setEditingItem(item)} className="text-yellow-400 hover:text-yellow-300 text-sm">Editar</button>
                            <button onClick={() => confirmDelete(item.id)} className="text-red-400 hover:text-red-300 text-sm">Excluir</button>
                        </div>
                    </div>
                ))}
            </div>
            <ConfirmDialog isOpen={isConfirmOpen} title={`Excluir ${itemName}`} message="Tem certeza? Esta ação não pode ser desfeita." onConfirm={handleDelete} onCancel={() => setConfirmOpen(false)} />
        </div>
    );
};


// --- CLIENTS ---
const ClientForm: React.FC<{ item: Client | null; onSave: (item: Client) => void; onCancel: () => void; }> = ({ item, onSave, onCancel }) => {
    const [formData, setFormData] = useState(item || {} as Omit<Client, 'id' | 'organizationId'>);
    const handleSubmit = () => onSave(formData as Client);
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => setFormData({...formData, [e.target.name]: e.target.value});
    return (
        <div className="bg-tertiary p-4 rounded-lg space-y-4 border border-border-color">
            <h4 className="font-bold text-lg text-primary">{('id' in formData) ? 'Editar' : 'Novo'} Cliente</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label="Nome da Empresa" name="companyName" value={formData.companyName || ''} onChange={handleChange} />
                <InputField label="URL da Logo" name="logoUrl" value={formData.logoUrl || ''} onChange={handleChange} />
                <InputField label="Endereço" name="fullAddress" value={formData.fullAddress || ''} onChange={handleChange} />
                <InputField label="Telefone" name="phone" value={formData.phone || ''} onChange={handleChange} />
                <InputField label="E-mail" name="email" type="email" value={formData.email || ''} onChange={handleChange} />
                <InputField label="WhatsApp" name="whatsapp" value={formData.whatsapp || ''} onChange={handleChange} />
                <InputField label="Responsável" name="responsiblePerson" value={formData.responsiblePerson || ''} onChange={handleChange} />
                <InputField label="Observação" name="observation" value={formData.observation || ''} onChange={handleChange} />
            </div>
            <div className="flex justify-end space-x-2"><SaveButton onClick={handleSubmit} /><CancelButton onClick={onCancel} /></div>
        </div>
    );
};
const ClientSettings: React.FC<{orgId: string}> = ({ orgId }) => <CrudManager<Client> orgId={orgId} title="Clientes" itemName="Cliente" getItems={settingsService.getClients} addItem={settingsService.addClient} updateItem={settingsService.updateClient} deleteItem={settingsService.deleteClient} renderForm={(props) => <ClientForm {...props} />} renderListItem={(item) => (<div><h4 className="font-bold text-primary">{item.companyName}</h4><p className="text-sm text-secondary">{item.responsiblePerson}</p></div>)} />;


// --- SERVICES ---
const ServiceTypeForm: React.FC<{ item: ServiceType | null; onSave: (item: ServiceType) => void; onCancel: () => void; }> = ({ item, onSave, onCancel }) => {
    const [formData, setFormData] = useState(item || {} as Omit<ServiceType, 'id' | 'organizationId'>);
    const handleSubmit = () => onSave(formData as ServiceType);
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => setFormData({...formData, [e.target.name]: e.target.name === 'hourlyRate' ? parseFloat(e.target.value) : e.target.value});
    return (
        <div className="bg-tertiary p-4 rounded-lg space-y-4 border border-border-color">
            <h4 className="font-bold text-lg text-primary">{('id' in formData) ? 'Editar' : 'Novo'} Serviço</h4>
            <InputField label="Nome do Serviço" name="name" value={formData.name || ''} onChange={handleChange} />
            <InputField label="Valor por Hora" name="hourlyRate" type="number" value={formData.hourlyRate || ''} onChange={handleChange} />
            <div className="flex justify-end space-x-2"><SaveButton onClick={handleSubmit} /><CancelButton onClick={onCancel} /></div>
        </div>
    );
};
const ServiceTypeSettings: React.FC<{orgId: string}> = ({ orgId }) => <CrudManager<ServiceType> orgId={orgId} title="Tipos de Serviço" itemName="Serviço" getItems={settingsService.getServiceTypes} addItem={settingsService.addServiceType} updateItem={settingsService.updateServiceType} deleteItem={settingsService.deleteServiceType} renderForm={(props) => <ServiceTypeForm {...props} />} renderListItem={(item) => (<div><h4 className="font-bold text-primary">{item.name}</h4><p className="text-sm text-secondary">R$ {item.hourlyRate.toFixed(2)}/hora</p></div>)} />;


// --- WORKSPACES ---
const WorkspaceForm: React.FC<{ item: Workspace | null; onSave: (item: Workspace) => void; onCancel: () => void; }> = ({ item, onSave, onCancel }) => {
    const [formData, setFormData] = useState(item || {} as Omit<Workspace, 'id' | 'organizationId'>);
    const handleSubmit = () => onSave(formData as Workspace);
    return (
        <div className="bg-tertiary p-4 rounded-lg space-y-4 border border-border-color">
            <h4 className="font-bold text-lg text-primary">{('id' in formData) ? 'Editar' : 'Nova'} Área de Trabalho</h4>
            <InputField label="Nome" name="name" value={formData.name || ''} onChange={(e) => setFormData({...formData, name: e.target.value})} />
            <label className="flex items-center space-x-2 text-primary"><input type="checkbox" checked={formData.adminOnly || false} onChange={e => setFormData({...formData, adminOnly: e.target.checked})} /><span>Visível apenas para Admins</span></label>
            <div className="flex justify-end space-x-2"><SaveButton onClick={handleSubmit} /><CancelButton onClick={onCancel} /></div>
        </div>
    );
};
const WorkspaceSettings: React.FC<{orgId: string}> = ({ orgId }) => <CrudManager<Workspace> orgId={orgId} title="Áreas de Trabalho" itemName="Área de Trabalho" getItems={projectService.getWorkspaces} addItem={projectService.addWorkspace} updateItem={projectService.updateWorkspace} deleteItem={projectService.deleteWorkspace} renderForm={(props) => <WorkspaceForm {...props} />} renderListItem={(item) => (<div><h4 className="font-bold text-primary">{item.name}</h4><p className="text-sm text-secondary">{item.adminOnly ? 'Admin' : 'Todos'}</p></div>)} />;


// --- JOB TITLES ---
const JobTitleForm: React.FC<{ item: JobTitle | null; onSave: (item: JobTitle) => void; onCancel: () => void; }> = ({ item, onSave, onCancel }) => {
    const [formData, setFormData] = useState(item || {} as Omit<JobTitle, 'id' | 'organizationId'>);
    const handleSubmit = () => onSave(formData as JobTitle);
    return (
        <div className="bg-tertiary p-4 rounded-lg space-y-4 border border-border-color">
            <h4 className="font-bold text-lg text-primary">{('id' in formData) ? 'Editar' : 'Novo'} Cargo</h4>
            <InputField label="Nome do Cargo" name="name" value={formData.name || ''} onChange={(e) => setFormData({...formData, name: e.target.value})} />
            <div className="flex justify-end space-x-2"><SaveButton onClick={handleSubmit} /><CancelButton onClick={onCancel} /></div>
        </div>
    );
};
const JobTitleSettings: React.FC<{orgId: string}> = ({ orgId }) => <CrudManager<JobTitle> orgId={orgId} title="Cargos" itemName="Cargo" getItems={settingsService.getJobTitles} addItem={settingsService.addJobTitle} updateItem={settingsService.updateJobTitle} deleteItem={settingsService.deleteJobTitle} renderForm={(props) => <JobTitleForm {...props} />} renderListItem={(item) => <h4 className="font-bold text-primary">{item.name}</h4>} />;


// --- EMPLOYEES ---
const EmployeeSettings: React.FC<{orgId: string}> = ({ orgId }) => {
    return <CrudManager<User> orgId={orgId} title="Funcionários" itemName="Funcionário" getItems={userService.getUsers} addItem={userService.addUser} updateItem={userService.updateUser} deleteItem={userService.deleteUser} renderForm={(props) => <EmployeeForm {...props} orgId={orgId} />} renderListItem={(item) => (<div><h4 className="font-bold text-primary">{item.name}</h4><p className="text-sm text-secondary capitalize">{item.jobTitle}</p><p className="text-sm text-cyan-400">{item.email}</p></div>)} />;
};

const EmployeeForm: React.FC<{ item: User | null; onSave: (item: User) => void; onCancel: () => void; orgId: string; }> = ({ item, onSave, onCancel, orgId }) => {
    const defaultUser: Omit<User, 'id' | 'organizationId'> = { name: '', email: '', password: '', role: 'employee', jobTitle: '', schedule: [{start: '09:00', end: '12:00'}, {start: '13:00', end: '18:00'}], monthlySalary: 0 };
    const [formData, setFormData] = useState<User | Omit<User, 'id' | 'organizationId'>>(item?.id ? item : defaultUser);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [jobTitles] = useState<JobTitle[]>(() => settingsService.getJobTitles(orgId));
    const [loading, setLoading] = useState(false);
    
    const validate = () => {
        const { isValid, errors: newErrors } = validator.validateUser(formData);
        setErrors(newErrors);
        return isValid;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleScheduleChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const {name, value} = e.target;
        const newSchedule = 'schedule' in formData ? [...formData.schedule] : [{start: '', end: ''}, {start: '', end: ''}];
        newSchedule[index] = {...newSchedule[index], [name]: value};
        setFormData({...formData, schedule: newSchedule});
    };

    const handleSubmit = () => {
        if (validate()) {
            setLoading(true);
            setTimeout(() => { onSave(formData as User); setLoading(false); }, 500);
        }
    };

    return (
        <div className="bg-tertiary p-4 rounded-lg space-y-4 border border-border-color">
            <h4 className="font-bold text-lg text-primary">{('id' in formData) ? 'Editar' : 'Novo'} Funcionário</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label="Nome" name="name" value={formData.name} onChange={handleChange} error={errors.name} />
                <InputField label="E-mail" name="email" type="email" value={formData.email} onChange={handleChange} error={errors.email} />
                <InputField label="Nova Senha" name="password" type="password" onChange={handleChange} placeholder={('id' in formData) ? 'Deixe em branco para não alterar' : ''} error={errors.password} />
                <InputField label="Salário Mensal" name="monthlySalary" type="number" value={formData.monthlySalary} onChange={e => setFormData({...formData, monthlySalary: parseFloat(e.target.value) || 0})} error={errors.monthlySalary} />
                <div>
                    <label className="block text-sm font-medium text-secondary">Cargo</label>
                    <select name="jobTitle" value={formData.jobTitle} onChange={handleChange} className="w-full bg-secondary p-2 rounded mt-1 border border-border-color"><option value="">Selecione...</option>{jobTitles.map(j => <option key={j.id} value={j.name}>{j.name}</option>)}</select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-secondary">Perfil</label>
                    <select name="role" value={formData.role} onChange={handleChange} className="w-full bg-secondary p-2 rounded mt-1 border border-border-color"><option value="employee">Funcionário</option><option value="admin">Administrador</option></select>
                </div>
            </div>
            <h5 className="text-md font-semibold text-primary pt-2 border-t border-border-color">Jornada de Trabalho</h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {('schedule' in formData && formData.schedule || [{},{}]).map((schedule, index) => (
                    <div key={index} className="p-3 bg-secondary rounded-md">
                        <p className="text-sm font-medium text-secondary/70 mb-2">Turno {index + 1}</p>
                        <div className="grid grid-cols-2 gap-4">
                           <InputField type="time" label="Início" name="start" value={schedule.start || ''} onChange={(e) => handleScheduleChange(e, index)} />
                           <InputField type="time" label="Fim" name="end" value={schedule.end || ''} onChange={(e) => handleScheduleChange(e, index)} />
                        </div>
                    </div>
                ))}
            </div>
            {errors.schedule && <p className="text-xs text-red-500 mt-1">{errors.schedule}</p>}
            <div className="flex justify-end space-x-2"><SaveButton onClick={handleSubmit} disabled={loading}>{loading && <LoadingSpinner />} Salvar</SaveButton><CancelButton onClick={onCancel} /></div>
        </div>
    );
};


export default SettingsPage;