
import React, { useState, useMemo } from 'react';
import * as timeService from '../services/timeService';
import * as userService from '../services/userService';
import * as projectService from '../services/projectService';
import * as settingsService from '../services/settingsService';
import * as auditService from '../services/auditService';
import { exportToPDF, exportToExcel } from '../services/exportService';
import { useSession } from '../contexts/SessionContext';

const ReportsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('hours');
  const { user } = useSession();

  if (!user) return null;

  const TabButton: React.FC<{tabName: string; label: string}> = ({tabName, label}) => (
    <button onClick={() => setActiveTab(tabName)} className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors ${activeTab === tabName ? 'bg-cyan-600 text-white' : 'text-secondary hover:bg-tertiary'}`}>
        {label}
    </button>
  );

  return (
    <div className="w-full max-w-7xl mx-auto bg-secondary p-4 sm:p-6 rounded-2xl shadow-lg border border-border-color">
      <h2 className="text-3xl font-bold text-cyan-400 mb-6">Relatórios</h2>
      
      <div className="mb-6 flex space-x-1 sm:space-x-2 border-b border-border-color pb-2 overflow-x-auto">
        <TabButton tabName="hours" label="Horas por Funcionário" />
        <TabButton tabName="productivity" label="Produtividade por Projeto" />
        <TabButton tabName="costs" label="Custos por Cliente" />
        <TabButton tabName="audit" label="Auditoria" />
      </div>
      
      <div>
        {activeTab === 'hours' && <HoursReport orgId={user.organizationId} />}
        {activeTab === 'productivity' && <ProductivityReport orgId={user.organizationId} />}
        {activeTab === 'costs' && <CostsReport orgId={user.organizationId} />}
        {activeTab === 'audit' && <AuditReport orgId={user.organizationId} />}
      </div>
    </div>
  );
};

const formatDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
};

const HoursReport: React.FC<{orgId: string}> = ({ orgId }) => {
    const users = userService.getUsers(orgId);
    const tasks = projectService.getTasks(orgId);
    const settings = settingsService.getSettings();

    const data = users.map(user => {
        const totalSeconds = tasks
            .filter(t => t.assignedUserId === user.id)
            .reduce((acc, t) => acc + t.timeSpentSeconds, 0);

        const scheduleSeconds = user.schedule.reduce((total, shift) => {
            const start = new Date(`1970-01-01T${shift.start}`);
            const end = new Date(`1970-01-01T${shift.end}`);
            return total + (end.getTime() - start.getTime()) / 1000;
        }, 0);
        
        const hourCost = (user.monthlySalary || 0) / ((scheduleSeconds / 3600) * 22); // Assuming 22 work days

        return {
            "Nome": user.name,
            "Cargo": user.jobTitle,
            "Horas Trabalhadas (Tarefas)": formatDuration(totalSeconds),
            "Custo/Hora (Aprox.)": `R$ ${hourCost.toFixed(2)}`,
            "Custo Total (Tarefas)": `R$ ${(totalSeconds / 3600 * hourCost).toFixed(2)}`
        };
    });

    const handleExport = (format: 'pdf' | 'excel') => {
        const exportData = data.map(d => Object.values(d));
        if (format === 'pdf') {
            exportToPDF('Relatorio_Horas_Funcionario', [Object.keys(data[0])], exportData, settings.appLogoUrl);
        } else {
            exportToExcel('Relatorio_Horas_Funcionario', [{ sheetName: 'Horas', data }]);
        }
    };
    
    return (
        <div>
            <div className="flex justify-end space-x-2 mb-4">
                <button onClick={() => handleExport('pdf')} className="text-sm bg-gray-600 px-3 py-1 rounded">Exportar PDF</button>
                <button onClick={() => handleExport('excel')} className="text-sm bg-gray-600 px-3 py-1 rounded">Exportar Excel</button>
            </div>
            <ReportTable headers={Object.keys(data[0] || [])} data={data} />
        </div>
    );
};

const ProductivityReport: React.FC<{orgId: string}> = ({ orgId }) => {
    const boards = projectService.getBoards(orgId);
    const clients = settingsService.getClients(orgId);
    const tasks = projectService.getTasks(orgId);
    const services = settingsService.getServiceTypes(orgId);
    const allStages = projectService.getStages(orgId);

    const data = boards.map(board => {
        const boardTasks = tasks.filter(t => t.boardId === board.id);
        const totalSeconds = boardTasks.reduce((acc, t) => acc + t.timeSpentSeconds, 0);
        const client = clients.find(c => c.id === boardTasks[0]?.clientId);
        const finalStageId = allStages.filter(s=>s.boardId === board.id).sort((a,b)=>b.order-a.order)[0]?.id

        const totalCost = boardTasks.reduce((acc, t) => {
            const service = services.find(s => s.id === t.serviceTypeId);
            const hourlyRate = service?.hourlyRate || 0;
            return acc + (t.timeSpentSeconds / 3600 * hourlyRate);
        }, 0);

        return {
            "Projeto (Quadro)": board.name,
            "Cliente": client?.companyName || 'N/A',
            "Tarefas Concluídas": boardTasks.filter(t => t.stageId === finalStageId).length,
            "Total de Horas": formatDuration(totalSeconds),
            "Custo Total": `R$ ${totalCost.toFixed(2)}`
        };
    });
    return <ReportTable headers={Object.keys(data[0] || [])} data={data} />;
}

const CostsReport: React.FC<{orgId: string}> = ({ orgId }) => {
     const clients = settingsService.getClients(orgId);
     const tasks = projectService.getTasks(orgId);
     const services = settingsService.getServiceTypes(orgId);

    const data = clients.map(client => {
        const clientTasks = tasks.filter(t => t.clientId === client.id);
        const totalSeconds = clientTasks.reduce((acc, t) => acc + t.timeSpentSeconds, 0);
        
        const totalCost = clientTasks.reduce((acc, t) => {
            const service = services.find(s => s.id === t.serviceTypeId);
            const hourlyRate = service?.hourlyRate || 0;
            return acc + (t.timeSpentSeconds / 3600 * hourlyRate);
        }, 0);
        
        return {
            "Cliente": client.companyName,
            "Total de Horas": formatDuration(totalSeconds),
            "Custo Total Faturado": `R$ ${totalCost.toFixed(2)}`
        }
    });

    return <ReportTable headers={Object.keys(data[0] || [])} data={data} />;
}

const AuditReport: React.FC<{orgId: string}> = ({ orgId }) => {
    const logs = useMemo(() => auditService.getAuditLogs(orgId).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()), [orgId]);

    const data = logs.map(log => ({
        "Data": new Date(log.timestamp).toLocaleString('pt-BR'),
        "Usuário": log.userName,
        "Ação": log.action,
        "Detalhes": log.details
    }));
    
    return <ReportTable headers={Object.keys(data[0] || [])} data={data} />;
};


const ReportTable: React.FC<{headers: string[], data: Record<string, any>[]}> = ({ headers, data }) => (
    <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-border-color">
            <thead className="bg-tertiary/50">
            <tr>
                {headers.map(header => <th key={header} scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">{header}</th>)}
            </tr>
            </thead>
            <tbody className="bg-secondary divide-y divide-border-color">
            {data.map((row, index) => (
                <tr key={index} className="hover:bg-tertiary transition-colors">
                    {headers.map(header => <td key={header} className="px-6 py-4 whitespace-nowrap text-sm text-primary">{row[header]}</td>)}
                </tr>
            ))}
            </tbody>
        </table>
    </div>
);


export default ReportsPage;