
import React, { useState, useEffect } from 'react';
import { useSession } from '../contexts/SessionContext';
import { getSettings } from '../services/settingsService';
import { useToast } from '../contexts/ToastContext';
import LoadingSpinner from '../components/LoadingSpinner';

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useSession();
  const settings = getSettings();
  const { addToast } = useToast();
  
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [lockoutTime, setLockoutTime] = useState(0);

  useEffect(() => {
    const attempts = parseInt(localStorage.getItem('loginAttempts') || '0', 10);
    const lockout = parseInt(localStorage.getItem('lockoutTime') || '0', 10);
    const now = Date.now();

    if (lockout > now) {
      setIsLocked(true);
      setLockoutTime(lockout);
    } else {
      localStorage.removeItem('loginAttempts');
      localStorage.removeItem('lockoutTime');
    }
    setLoginAttempts(attempts);
  }, []);
  
  useEffect(() => {
    let interval: number;
    if (isLocked) {
      interval = window.setInterval(() => {
        const now = Date.now();
        if (lockoutTime > now) {
          setLockoutTime(lockoutTime);
        } else {
          setIsLocked(false);
          setLoginAttempts(0);
          localStorage.removeItem('loginAttempts');
          localStorage.removeItem('lockoutTime');
          clearInterval(interval);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isLocked, lockoutTime]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) {
      addToast('Muitas tentativas de login. Tente novamente mais tarde.', 'error');
      return;
    }
    
    setLoading(true);
    const success = await login(email, password);
    setLoading(false);

    if (!success) {
      const newAttempts = loginAttempts + 1;
      setLoginAttempts(newAttempts);
      localStorage.setItem('loginAttempts', newAttempts.toString());

      if (newAttempts >= MAX_LOGIN_ATTEMPTS) {
        const newLockoutTime = Date.now() + LOCKOUT_MINUTES * 60 * 1000;
        localStorage.setItem('lockoutTime', newLockoutTime.toString());
        setIsLocked(true);
        setLockoutTime(newLockoutTime);
        addToast(`Muitas tentativas de login. Acesso bloqueado por ${LOCKOUT_MINUTES} minutos.`, 'error');
      } else {
        addToast(`E-mail ou senha inválidos. Tentativa ${newAttempts} de ${MAX_LOGIN_ATTEMPTS}.`, 'error');
      }
    }
  };
  
  const getRemainingLockout = () => {
    const remaining = Math.ceil((lockoutTime - Date.now()) / 1000);
    const minutes = Math.floor(remaining / 60);
    const seconds = remaining % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-primary">
      <div className="w-full max-w-md p-8 space-y-8 bg-secondary rounded-2xl shadow-2xl border border-border-color">
        <div className="text-center">
          {settings.appLogoUrl ? (
            <img src={settings.appLogoUrl} alt="App Logo" className="h-12 w-auto mx-auto" />
          ) : (
             <span className="text-5xl">🏢</span>
          )}
          <h1 className="text-4xl font-bold text-cyan-400 mt-4">{settings.appName}</h1>
          <p className="text-secondary">Faça login para continuar</p>
        </div>
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label className="block text-sm font-medium text-secondary">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2 mt-1 text-primary bg-tertiary border border-border-color rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="seu@email.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-3 py-2 mt-1 text-primary bg-tertiary border border-border-color rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="********"
            />
          </div>
          
          <div>
            <button
              type="submit"
              disabled={loading || isLocked}
              className="w-full py-3 font-semibold text-white bg-cyan-600 rounded-md hover:bg-cyan-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading && <LoadingSpinner />}
              {isLocked ? `Bloqueado (${getRemainingLockout()})` : 'Entrar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;