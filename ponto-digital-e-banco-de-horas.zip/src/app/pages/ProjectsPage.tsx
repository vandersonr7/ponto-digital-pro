
import React, { useState, useEffect } from 'react';
import { Workspace, Board, User } from '../types';
import * as projectService from '../services/projectService';
import KanbanBoard from '../components/KanbanBoard';
import { useSession } from '../contexts/SessionContext';
import ConfirmDialog from '../components/ConfirmDialog';
import { useToast } from '../contexts/ToastContext';
import { useAudit } from '../contexts/AuditContext';
import LoadingSpinner from '../components/LoadingSpinner';


const ProjectsPage: React.FC = () => {
  const { user } = useSession() as { user: User };
  const { addToast } = useToast();
  const { logAction } = useAudit();
  const [loading, setLoading] = useState(true);
  
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [boards, setBoards] = useState<Board[]>([]);
  const [selectedWorkspace, setSelectedWorkspace] = useState<Workspace | null>(null);
  const [selectedBoard, setSelectedBoard] = useState<Board | null>(null);

  const [isWorkspaceModalOpen, setWorkspaceModalOpen] = useState(false);
  const [isBoardModalOpen, setBoardModalOpen] = useState(false);
  const [isConfirmOpen, setConfirmOpen] = useState(false);
  
  const [editingWorkspace, setEditingWorkspace] = useState<Workspace | null>(null);
  const [editingBoard, setEditingBoard] = useState<Board | null>(null);
  const [itemToDelete, setItemToDelete] = useState<{type: 'workspace' | 'board', id: string} | null>(null);

  const reloadData = () => {
    setLoading(true);
    const allWorkspaces = projectService.getWorkspaces(user.organizationId);
    const visibleWorkspaces = user.role === 'admin' ? allWorkspaces : allWorkspaces.filter(ws => !ws.adminOnly);
    setWorkspaces(visibleWorkspaces);
    setBoards(projectService.getBoards(user.organizationId));
    setLoading(false);
  };

  useEffect(() => {
    reloadData();
  }, [user.id]);

  const handleSelectWorkspace = (workspace: Workspace) => {
    setSelectedWorkspace(workspace);
    setSelectedBoard(null);
  };
  
  const handleSaveWorkspace = (name: string, adminOnly: boolean) => {
    const action = editingWorkspace ? 'Update' : 'Create';
    if (editingWorkspace) {
      projectService.updateWorkspace(user.organizationId, { ...editingWorkspace, name, adminOnly });
    } else {
      projectService.addWorkspace(user.organizationId, { name, adminOnly });
    }
    logAction(action, `Área de Trabalho: ${name}`);
    addToast(`Área de Trabalho ${editingWorkspace ? 'atualizada' : 'criada'} com sucesso!`, 'success');
    closeWorkspaceModal();
    reloadData();
  };

  const confirmDelete = (type: 'workspace' | 'board', id: string) => {
    setItemToDelete({ type, id });
    setConfirmOpen(true);
  };
  
  const handleDelete = () => {
    if (!itemToDelete) return;
    
    const { type, id } = itemToDelete;
    let itemName = '';
    
    if (type === 'workspace') {
      itemName = workspaces.find(ws => ws.id === id)?.name || '';
      projectService.deleteWorkspace(user.organizationId, id);
      if (selectedWorkspace?.id === id) {
        setSelectedWorkspace(null);
        setSelectedBoard(null);
      }
    } else { // board
      itemName = boards.find(b => b.id === id)?.name || '';
      projectService.deleteBoard(user.organizationId, id);
      if(selectedBoard?.id === id) {
        setSelectedBoard(null);
      }
    }

    logAction('Delete', `${type === 'workspace' ? 'Área de Trabalho' : 'Quadro'}: ${itemName}`);
    addToast(`${type === 'workspace' ? 'Área de Trabalho' : 'Quadro'} excluída com sucesso.`, 'success');
    reloadData();
    setConfirmOpen(false);
    setItemToDelete(null);
  };

  const openWorkspaceModal = (ws: Workspace | null = null) => { setEditingWorkspace(ws); setWorkspaceModalOpen(true); };
  const closeWorkspaceModal = () => { setEditingWorkspace(null); setWorkspaceModalOpen(false); };

  const handleSaveBoard = (name: string) => {
    if (!selectedWorkspace) return;
    const action = editingBoard ? 'Update' : 'Create';

    if (editingBoard) {
      projectService.updateBoard(user.organizationId, { ...editingBoard, name });
    } else {
      projectService.addBoard(user.organizationId, { name, workspaceId: selectedWorkspace.id });
    }
    logAction(action, `Quadro: ${name} (em ${selectedWorkspace.name})`);
    addToast(`Quadro ${editingBoard ? 'atualizado' : 'criado'} com sucesso!`, 'success');
    closeBoardModal();
    reloadData();
  };

  const openBoardModal = (board: Board | null = null) => { setEditingBoard(board); setBoardModalOpen(true); };
  const closeBoardModal = () => { setEditingBoard(null); setBoardModalOpen(false); };

  const workspaceBoards = selectedWorkspace ? boards.filter(b => b.workspaceId === selectedWorkspace.id) : [];

  if (loading) {
    return <div className="flex justify-center items-center h-full"><LoadingSpinner /></div>;
  }

  return (
    <div className="w-full max-w-full mx-auto" style={{height: 'calc(100vh - 150px)'}}>
      <div className="flex flex-col md:flex-row gap-6 h-full">
        {/* Sidebar */}
        <aside className="w-full md:w-1/4 lg:w-1/5 bg-secondary p-4 rounded-2xl flex flex-col border border-border-color">
          {/* Workspaces */}
          <div className="flex justify-between items-center mb-4 flex-shrink-0">
            <h3 className="text-lg font-bold text-primary">Áreas de Trabalho</h3>
            {user.role === 'admin' && <button onClick={() => openWorkspaceModal()} className="text-cyan-400 hover:text-white font-bold text-xl">+</button>}
          </div>
          <ul className="space-y-1 overflow-y-auto flex-grow mb-4">
            {workspaces.map(ws => (
              <li key={ws.id} className="group">
                <div className="flex items-center justify-between">
                  <button onClick={() => handleSelectWorkspace(ws)} className={`w-full text-left px-3 py-2 rounded-md text-primary text-sm truncate transition-colors ${selectedWorkspace?.id === ws.id ? 'bg-cyan-600' : 'hover:bg-tertiary'}`}>
                    {ws.name}
                  </button>
                  {user.role === 'admin' && (
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                        <button onClick={() => openWorkspaceModal(ws)} className="p-1 text-secondary hover:text-primary">✏️</button>
                        <button onClick={() => confirmDelete('workspace', ws.id)} className="p-1 text-secondary hover:text-red-400">🗑️</button>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>

          {/* Boards */}
          {selectedWorkspace && (
            <div className="mt-auto border-t border-border-color pt-4 flex-shrink-0">
              <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-primary">Quadros</h3>
                  <button onClick={() => openBoardModal()} className="text-cyan-400 hover:text-white font-bold text-xl">+</button>
              </div>
              <ul className="space-y-1">
                {workspaceBoards.map(board => (
                  <li key={board.id} className="group">
                    <div className="flex items-center justify-between">
                        <button onClick={() => setSelectedBoard(board)} className={`w-full text-left px-3 py-2 rounded-md text-sm truncate transition-colors ${selectedBoard?.id === board.id ? 'bg-cyan-800 font-semibold text-white' : 'text-secondary hover:bg-tertiary'}`}>
                          {board.name}
                        </button>
                         <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                            <button onClick={() => openBoardModal(board)} className="p-1 text-secondary hover:text-primary">✏️</button>
                            <button onClick={() => confirmDelete('board', board.id)} className="p-1 text-secondary hover:text-red-400">🗑️</button>
                        </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>

        {/* Main content */}
        <main className="w-full md:w-3/4 lg:w-4/5 h-full overflow-hidden">
          {selectedBoard ? (
            <KanbanBoard board={selectedBoard} key={selectedBoard.id} />
          ) : (
            <div className="flex items-center justify-center h-full bg-secondary rounded-2xl border border-border-color">
              <p className="text-secondary text-xl text-center">Selecione uma área de trabalho e um quadro para começar.</p>
            </div>
          )}
        </main>
      </div>

      {isWorkspaceModalOpen && <WorkspaceModal workspace={editingWorkspace} onSave={handleSaveWorkspace} onClose={closeWorkspaceModal} />}
      {isBoardModalOpen && <BoardModal board={editingBoard} onSave={handleSaveBoard} onClose={closeBoardModal} />}
      <ConfirmDialog 
        isOpen={isConfirmOpen}
        title={`Excluir ${itemToDelete?.type === 'workspace' ? 'Área de Trabalho' : 'Quadro'}`}
        message="Tem certeza? Esta ação é permanente e removerá todos os itens contidos (quadros, etapas e tarefas)."
        onConfirm={handleDelete}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  );
};

// Modals
const WorkspaceModal: React.FC<{ workspace: Workspace | null; onSave: (name: string, adminOnly: boolean) => void; onClose: () => void }> = ({ workspace, onSave, onClose }) => {
    const [name, setName] = useState(workspace?.name || '');
    const [adminOnly, setAdminOnly] = useState(workspace?.adminOnly || false);
    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-secondary p-6 rounded-lg w-full max-w-md border border-border-color">
                <h3 className="text-xl font-bold mb-4">{workspace ? 'Editar' : 'Nova'} Área de Trabalho</h3>
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Nome" className="w-full bg-tertiary p-2 rounded mb-4 border border-border-color" />
                <label className="flex items-center space-x-2 text-primary mb-4"><input type="checkbox" checked={adminOnly} onChange={e => setAdminOnly(e.target.checked)} /><span>Visível apenas para Admins</span></label>
                <div className="flex justify-end space-x-2">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-600 rounded">Cancelar</button>
                    <button onClick={() => onSave(name, adminOnly)} className="px-4 py-2 bg-cyan-600 rounded">Salvar</button>
                </div>
            </div>
        </div>
    );
};

const BoardModal: React.FC<{ board: Board | null; onSave: (name: string) => void; onClose: () => void }> = ({ board, onSave, onClose }) => {
    const [name, setName] = useState(board?.name || '');
    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-secondary p-6 rounded-lg w-full max-w-md border border-border-color">
                <h3 className="text-xl font-bold mb-4">{board ? 'Editar' : 'Novo'} Quadro</h3>
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Nome" className="w-full bg-tertiary p-2 rounded mb-4 border border-border-color" />
                <div className="flex justify-end space-x-2">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-600 rounded">Cancelar</button>
                    <button onClick={() => onSave(name)} className="px-4 py-2 bg-cyan-600 rounded">Salvar</button>
                </div>
            </div>
        </div>
    );
};

export default ProjectsPage;
