
import React, { useState } from 'react';
import { Organization, User } from '../types';
import * as organizationService from '../services/organizationService';
import { useToast } from '../contexts/ToastContext';
import * as validator from '../services/validation';
import LoadingSpinner from '../components/LoadingSpinner';

const PlatformAdminPage: React.FC = () => {
    const [organizations, setOrganizations] = useState<Organization[]>(organizationService.getOrganizations());
    const [isCreating, setIsCreating] = useState(false);
    const [formData, setFormData] = useState({ orgName: '', adminName: '', adminEmail: '', adminPassword: '' });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [loading, setLoading] = useState(false);
    const { addToast } = useToast();

    const validate = () => {
        const newErrors: Record<string, string> = {};
        if (!validator.validateRequiredField(formData.orgName)) newErrors.orgName = "Nome da organização é obrigatório.";
        if (!validator.validateRequiredField(formData.adminName)) newErrors.adminName = "Nome do admin é obrigatório.";
        if (!validator.validateEmail(formData.adminEmail)) newErrors.adminEmail = "E-mail do admin inválido.";
        if (!validator.validatePassword(formData.adminPassword)) newErrors.adminPassword = "Senha: min 6 chars, 1 maiúscula, 1 número.";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleCreate = () => {
        if (!validate()) {
            addToast('Por favor, corrija os erros no formulário.', 'error');
            return;
        }
        setLoading(true);
        const adminData: Omit<User, 'id' | 'organizationId' | 'role'> = {
            name: formData.adminName,
            email: formData.adminEmail,
            password: formData.adminPassword,
            jobTitle: 'Administrador',
            monthlySalary: 0,
            schedule: [],
        };
        organizationService.addOrganizationAndAdmin(formData.orgName, adminData);
        setTimeout(() => {
            setLoading(false);
            addToast('Organização criada com sucesso!', 'success');
            setOrganizations(organizationService.getOrganizations());
            setIsCreating(false);
            setFormData({ orgName: '', adminName: '', adminEmail: '', adminPassword: '' });
        }, 500);
    };

    const InputField = (props: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }) => (
        <div>
            <label className="block text-sm font-medium text-secondary">{props.label}</label>
            <input {...props} className={`w-full bg-tertiary p-2 rounded mt-1 border ${props.error ? 'border-red-500' : 'border-border-color'} focus:ring-cyan-500 focus:border-cyan-500 transition-colors`} />
            {props.error && <p className="text-xs text-red-500 mt-1">{props.error}</p>}
        </div>
    );

    return (
        <div className="w-full max-w-4xl mx-auto bg-secondary p-6 rounded-2xl shadow-lg border border-border-color">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-cyan-400">Gerenciamento da Plataforma</h2>
                {!isCreating && (
                    <button onClick={() => setIsCreating(true)} className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-md text-white font-semibold">
                        + Nova Organização
                    </button>
                )}
            </div>

            {isCreating ? (
                <div className="bg-tertiary p-6 rounded-lg space-y-4 border border-border-color">
                    <h3 className="text-xl font-bold text-primary">Cadastrar Nova Organização</h3>
                    <InputField label="Nome da Organização" name="orgName" value={formData.orgName} onChange={e => setFormData({...formData, orgName: e.target.value})} error={errors.orgName} />
                    <hr className="border-border-color"/>
                    <h4 className="font-semibold text-secondary">Usuário Administrador Inicial</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <InputField label="Nome do Admin" name="adminName" value={formData.adminName} onChange={e => setFormData({...formData, adminName: e.target.value})} error={errors.adminName} />
                        <InputField label="Email do Admin" name="adminEmail" type="email" value={formData.adminEmail} onChange={e => setFormData({...formData, adminEmail: e.target.value})} error={errors.adminEmail} />
                    </div>
                    <InputField label="Senha para o Admin" name="adminPassword" type="password" value={formData.adminPassword} onChange={e => setFormData({...formData, adminPassword: e.target.value})} error={errors.adminPassword} />
                    <div className="flex justify-end space-x-2 pt-4">
                        <button onClick={() => setIsCreating(false)} className="px-4 py-2 bg-gray-500 hover:bg-gray-400 rounded text-sm text-white font-semibold">Cancelar</button>
                        <button onClick={handleCreate} disabled={loading} className="px-4 py-2 bg-green-600 hover:bg-green-500 rounded text-sm text-white font-semibold flex items-center justify-center disabled:opacity-50">
                            {loading && <LoadingSpinner />}
                            Criar Organização
                        </button>
                    </div>
                </div>
            ) : (
                <div className="space-y-3">
                    <h3 className="text-xl font-semibold text-primary mb-4">Organizações Cadastradas</h3>
                    {organizations.map(org => (
                        <div key={org.id} className="bg-tertiary p-4 rounded-lg border border-border-color">
                            <p className="font-bold text-primary">{org.name}</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default PlatformAdminPage;
