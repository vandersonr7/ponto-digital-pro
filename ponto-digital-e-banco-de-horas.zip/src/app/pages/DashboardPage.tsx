
import React, { useState, useEffect } from 'react';
import { Punch, UserStatus } from '../types';
import Clock from '../components/Clock';
import TimeLog from '../components/TimeLog';
import HourBankSummary from '../components/HourBankSummary';
import PunchActions from '../components/PunchActions';
import { useAuth } from '../hooks/useAuth';
import * as timeService from '../services/timeService';
import { useToast } from '../contexts/ToastContext';
import { useSession } from '../contexts/SessionContext';

const parseTimeToMs = (time: string) => {
    if (!time) return 0;
    const [hours, minutes] = time.split(':').map(Number);
    return (hours * 60 + minutes) * 60 * 1000;
}

const DashboardPage: React.FC = () => {
  const { user } = useSession();
  const { activeTask, setActiveTask } = useAuth();
  const [punches, setPunches] = useState<Punch[]>([]);
  const [status, setStatus] = useState<UserStatus>('out');
  const { addToast } = useToast();
  
  useEffect(() => {
    if (user) {
      const userPunches = timeService.getPunchesForUser(user.organizationId, user.id);
      setPunches(userPunches);
      
      if (userPunches.length > 0) {
        const lastPunch = userPunches[userPunches.length - 1];
        if (lastPunch.type === 'in' || lastPunch.type === 'break_end') {
          setStatus('in');
        } else if (lastPunch.type === 'break_start') {
          setStatus('on_break');
        } else {
          setStatus('out');
        }
      } else {
          setStatus('out');
      }
    }
  }, [user]);

  const handlePunch = async (type: Punch['type']) => {
      if (!user) return;
      
      if ((type === 'out' || type === 'break_start') && activeTask) {
          setActiveTask(null);
          addToast(`Timer da tarefa "${activeTask.title}" pausado.`, 'info');
      }

      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            if (!navigator.geolocation) {
                return reject(new Error('Geolocalização não é suportada por este navegador.'));
            }
            navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
        });
        
        const location = { latitude: position.coords.latitude, longitude: position.coords.longitude };
        const newPunch: Punch = { type, timestamp: new Date(), location, taskId: activeTask?.id };
        timeService.savePunchForUser(user.organizationId, user.id, newPunch);
        setPunches(prev => [...prev, newPunch]);
        
        let newStatus: UserStatus = status;
        let message = '';
        if (type === 'in') { newStatus = 'in'; message = 'Entrada registrada com sucesso!'; }
        else if (type === 'out') { newStatus = 'out'; message = 'Saída registrada. Bom descanso!'; }
        else if (type === 'break_start') { newStatus = 'on_break'; message = 'Pausa iniciada.'; }
        else if (type === 'break_end') { newStatus = 'in'; message = 'De volta ao trabalho!'; }
        setStatus(newStatus);
        addToast(message, 'success');

      } catch (error) {
        let errorMessage = 'Não foi possível obter sua localização. O ponto não foi registrado.';
        if (error instanceof GeolocationPositionError) {
             if (error.code === 1) errorMessage = 'Você precisa permitir o acesso à localização para bater o ponto.';
        }
        addToast(errorMessage, 'error');
      }
  };
  
  if (!user) return null;

  const scheduleDurationMs = user.schedule.reduce((total, shift) => {
    const startMs = parseTimeToMs(shift.start);
    const endMs = parseTimeToMs(shift.end);
    return endMs > startMs ? total + (endMs - startMs) : total;
  }, 0);

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-primary">Bem-vindo(a), {user.name}!</h2>
        <p className="text-secondary">Pronto para registrar seu dia?</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-secondary border border-border-color rounded-2xl shadow-2xl p-6 flex flex-col items-center justify-center space-y-6 order-2 lg:order-1">
          <Clock />
           {activeTask && (
            <div className="text-center p-3 bg-tertiary rounded-lg w-full max-w-sm">
                <p className="text-sm text-cyan-400">Timer ativo na tarefa:</p>
                <p className="font-bold text-primary text-lg truncate">{activeTask.title}</p>
            </div>
           )}
          <PunchActions status={status} onPunch={handlePunch} />
        </div>
        
        <div className="space-y-8 order-1 lg:order-2">
          <HourBankSummary punches={punches} workDayDurationMs={scheduleDurationMs}/>
          <TimeLog punches={punches} />
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
