
import React, { useState, useEffect, useMemo, ReactNode } from 'react';
import { getAllPunchesForToday } from '../services/timeService';
import { User, Punch } from '../types';
import { useSession } from '../contexts/SessionContext';

interface DailyPunches {
  user: User;
  punches: Punch[];
}

const formatDuration = (milliseconds: number): string => {
  if (isNaN(milliseconds) || milliseconds < 0) milliseconds = 0;
  const totalSeconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
};

const calculateWorkAndBreakMs = (punches: Punch[]) => {
    let totalWork = 0;
    let totalBreak = 0;
    let lastIn: Date | null = null;
    let lastBreakStart: Date | null = null;
    const now = new Date();

    punches.forEach(punch => {
        const timestamp = new Date(punch.timestamp);
        switch(punch.type) {
            case 'in':
                if (!lastIn) lastIn = timestamp;
                break;
            case 'out':
                if (lastIn) {
                    totalWork += (timestamp.getTime() - lastIn.getTime());
                    lastIn = null;
                }
                break;
            case 'break_start':
                if (lastIn && !lastBreakStart) {
                    lastBreakStart = timestamp;
                }
                break;
            case 'break_end':
                if (lastBreakStart) {
                    totalBreak += (timestamp.getTime() - lastBreakStart.getTime());
                    lastBreakStart = null;
                }
                break;
        }
    });

    if(lastIn && !lastBreakStart) {
        totalWork += (now.getTime() - lastIn.getTime());
    }

    if(lastBreakStart) {
        totalBreak += (now.getTime() - lastBreakStart.getTime());
    }
    
    return { workedMs: totalWork, breakMs: totalBreak };
};

// Copied from TimeLog.tsx for detailed view
const punchTypeMap: { [key in Punch['type']]: { text: string; color: string; icon: ReactNode } } = {
  in: { text: 'Entrada', color: 'text-green-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414l-3-3z" clipRule="evenodd" /></svg> },
  out: { text: 'Saída', color: 'text-red-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-.707-4.707a1 1 0 001.414 1.414l3-3a1 1 0 00-1.414-1.414L11 10.586V7a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3z" clipRule="evenodd" /></svg> },
  break_start: { text: 'Início Pausa', color: 'text-yellow-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9 9a1 1 0 000 2h2a1 1 0 100-2H9z" clipRule="evenodd" /></svg> },
  break_end: { text: 'Fim Pausa', color: 'text-blue-400', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a8 8 0 100 16 8 8 0 000-16zM9.555 12.168l-3.197-2.132A1 1 0 017 9.87v4.263a1 1 0 01-1.555.832l-3.197-2.132a1 1 0 010-1.664l3.197-2.132A1 1 0 017 8.13v4.263a1 1 0 011.555.832l3.197 2.132a1 1 0 010 1.664l-3.197 2.132A1 1 0 019.555 12.168z" /></svg> },
};


const MonitorPage: React.FC = () => {
  const { user } = useSession();
  const [dailyData, setDailyData] = useState<DailyPunches[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUserPunches, setSelectedUserPunches] = useState<DailyPunches | null>(null);

  const fetchData = () => {
    if (!user) return;
    const data = getAllPunchesForToday(user.organizationId);
    setDailyData(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    const intervalId = setInterval(fetchData, 30000); // Auto-refresh every 30 seconds
    return () => clearInterval(intervalId);
  }, [user]);

  const processedData = useMemo(() => {
    return dailyData.map(item => {
      const { punches } = item;
      const firstIn = punches.find(p => p.type === 'in');
      const lastOut = [...punches].reverse().find(p => p.type === 'out');
      const lastPunch = punches.length > 0 ? punches[punches.length - 1] : null;

      const { workedMs, breakMs } = calculateWorkAndBreakMs(punches);
      const netWorkedMs = workedMs - breakMs;

      let status = 'Não Iniciado';
      let statusColor = 'text-gray-400';
      if(lastPunch) {
          if (lastPunch.type === 'in' || lastPunch.type === 'break_end') {
              status = 'Trabalhando';
              statusColor = 'text-green-400';
          } else if (lastPunch.type === 'break_start') {
              status = 'Em Pausa';
              statusColor = 'text-yellow-400';
          } else if (lastPunch.type === 'out') {
              status = 'Finalizado';
              statusColor = 'text-red-400';
          }
      }

      return {
        userId: item.user.id,
        userName: item.user.name,
        firstInTime: firstIn ? firstIn.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '--:--',
        lastOutTime: lastOut ? lastOut.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '--:--',
        totalWorked: formatDuration(netWorkedMs),
        status,
        statusColor
      };
    });
  }, [dailyData]);

  const handleRowClick = (userId: string) => {
    const userData = dailyData.find(d => d.user.id === userId);
    if (userData) {
      setSelectedUserPunches(userData);
    }
  };

  const handleCloseModal = () => {
    setSelectedUserPunches(null);
  };

  return (
    <div className="w-full max-w-6xl mx-auto bg-gray-800 p-6 rounded-2xl shadow-lg">
      <h2 className="text-3xl font-bold text-cyan-400 mb-6">Monitoramento de Ponto - Hoje</h2>
      {loading ? (
        <p>Carregando...</p>
      ) : (
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-gray-700/50">
                <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Funcionário</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Primeira Entrada</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Última Saída</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Total Trabalhado</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                </tr>
                </thead>
                <tbody className="bg-gray-800 divide-y divide-gray-700">
                {processedData.map(data => (
                    <tr 
                        key={data.userId}
                        onClick={() => handleRowClick(data.userId)}
                        className="cursor-pointer hover:bg-gray-700/50 transition-colors duration-200"
                    >
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">{data.userName}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{data.firstInTime}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{data.lastOutTime}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-cyan-400">{data.totalWorked}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-bold">
                            <span className={data.statusColor}>{data.status}</span>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
      )}
      {selectedUserPunches && (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50"
            onClick={handleCloseModal}
        >
            <div 
                className="bg-gray-800 rounded-2xl shadow-xl p-6 w-full max-w-md m-4 border border-gray-700"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center border-b-2 border-gray-700 pb-3 mb-4">
                    <h3 className="text-xl font-bold text-cyan-400">Detalhes de Ponto - {selectedUserPunches.user.name}</h3>
                    <button onClick={handleCloseModal} className="text-gray-400 hover:text-white text-3xl leading-none font-bold">&times;</button>
                </div>
                <div className="max-h-80 overflow-y-auto pr-2">
                    {selectedUserPunches.punches.length === 0 ? (
                        <p className="text-gray-400 text-center py-8">Nenhum registro hoje.</p>
                    ) : (
                        <ul className="space-y-3">
                        {[...selectedUserPunches.punches].reverse().map((punch, index) => (
                            <li key={index} className="bg-gray-700/50 p-3 rounded-lg">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <span className={`mr-3 ${punchTypeMap[punch.type].color}`}>{punchTypeMap[punch.type].icon}</span>
                                        <span className={`font-semibold ${punchTypeMap[punch.type].color}`}>
                                            {punchTypeMap[punch.type].text}
                                        </span>
                                    </div>
                                    <span className="font-mono text-gray-300">{new Date(punch.timestamp).toLocaleTimeString('pt-BR')}</span>
                                </div>
                                {punch.location && (
                                    <div className="mt-2 pl-8 text-xs text-gray-400 flex items-center">
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                                      </svg>
                                      <a
                                        href={`https://www.google.com/maps?q=${punch.location.latitude},${punch.location.longitude}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="hover:text-cyan-400 hover:underline"
                                      >
                                        Ver no Mapa ({punch.location.latitude.toFixed(4)}, {punch.location.longitude.toFixed(4)})
                                      </a>
                                    </div>
                                )}
                            </li>
                        ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default MonitorPage;
